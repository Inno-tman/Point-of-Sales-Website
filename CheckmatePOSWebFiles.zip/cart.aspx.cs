﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Configuration;

namespace CheckMWebs
{
    public partial class cart : System.Web.UI.Page
    {
        public int GrapeQuant = 1;
        public int BananaQuant = 1;
        public int NartjieQuant = 1;
        public int OrangeQuant = 1;
        public int AppleQuant = 1;
        public int PlumQuant = 1;
        public int FerreroQuant = 1;
        public int SnowballQuant = 1;
        public int BlackForrestQuant = 1;
        public int VelvetQuant = 1;
        public int LOngDonutQuant = 1;
        public int RoundDonutQuant = 1;
        public int QueenCakeQuant = 1;
        public int PastryPuffQuant = 1;
        public int CreamBunsQuant = 1;
        public int PlainScornQuant = 1;
        public int QueencakeCheeseQuant = 1;
        public int RaisinScornQuant = 1;
        public int MeltingMomentQuant = 1;
        public int ChocolateMoueseQuant = 1;
        public int BarOneSquareQuant = 1;
        public int RedBull250Quant = 1;
        public int RedbullQuant = 1;
        public int CustardcaramelQuant = 1;
        public int SmoothieQuant = 1;
        public int ReboostQuant = 1;
        public int StillWaterQuant = 1;
        public int SparkingWaterQuant = 1;
        public int SmallFriedQuant = 1;
        public int LargeFriedQuant = 1;
        public int swissrollquant = 1;
        public int BeefburgerQuant = 1;
        public int HotDogQuant = 1;
        public int hotcrossbunQuant = 1;
        public int cupcakeQuant = 1;
        public int FruitSaladQuant = 1;
        public int IceCreamConeQuant = 1;
        public int IceCreamCupQuant = 1;
        public int IceCreamOreoQuant = 1;
        public int cheeseCakeQuant = 1;
        public int caramelcakeQuant = 1;
        public int BlueberryQuant = 1;
        public int FruitSliceQuant = 1;






        public decimal Appleprice, Orangeprice, Bananaprice, Nartjieprice, Peachprice;
        public decimal grapeprice, ferreroprice, snowballprice, velvetprice, blackforrestprice, rounddonutprice, longdonutprice;
        public decimal QueenCaketPrice, PastryPuffPrice, CreamBunsPrice, PlainScortPrice, QueencakeCheesePrice, RaisinScornPrice, MeltingMomentPrice, ChocolateMouesePrice, BarOneSquarePrice;
        public decimal RedBull250Price, RedbullPrice, SmoothiePrice, ReboostPrice, StillWaterPrice, SparkingWaterPrice, SmallFriedPrice, LargeFriedPrice, BeefburgerPrice, HotDogPrice, FruitSaladPrice;
        public decimal IceCreamConePrice, IceCreamCupPrice, IceCreamOreoPrice;



        public decimal AppleTot, NartjieTot, GrapeTot, PeachTot, BananaTot, OrangeTot;
        public decimal FerreroTot, LongDonutTot, roundDonutTot, SnowballTot, blackForrestTot, VelvetTot;
        public decimal cheeseCakeTot, CustardCaramelTot, FruitSliceTot, HotCrossBunTot, CupCakeTot, CaramelcakeTot, SwizzRollTot, BlueberryTot, BarOnesliceTot;
        public decimal QueenCaketTot, PastryPuffTot, CreamBunsTot, PlainScortTot, QueencakeCheeseTot, RaisinScornTot, MeltingMomentTot, ChocolateMoueseTot, BarOneSquareTot;
        public decimal RedBull250Tot, RedbullTot, SmoothieTot, ReboostTot, StillWaterTot, SparkingWaterTot, smallFriedTot, LargeFriedTot, BeefburgerTot, HotDogTot, FruitSaladTot;

        public decimal AppleTot1, NartjieTot1, GrapeTot1, PeachTot1, BananaTot1, OrangeTot1;

        public decimal IceCreamConeTot, IceCreamCupTot, IceCreamOreoTot;
        public int OrderID;
        public decimal TOTALCOST;





        private List<string> selectedItems = new List<string>(); // Declare the list at the class level

        private decimal GetProductPrice(string productDescription)
        {
            decimal price = 0;
            string connectionString = ConfigurationManager.ConnectionStrings["GroupWst9ConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT [Price] FROM [Product] WHERE [Description] = @Description";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Description", productDescription);
                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        decimal.TryParse(result.ToString(), out price);
                    }
                }
            }

            return price;
        }
        private int GetProductID(string productDescription)
        {
            int ID = 0;
            string connectionString = ConfigurationManager.ConnectionStrings["GroupWst9ConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT [Product_ID] FROM [Product] WHERE [Description] = @Description";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Description", productDescription);
                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        int.TryParse(result.ToString(), out ID);
                    }
                }
                return ID;
            }
        }
        private bool IsItemInCart(string itemName)
        {
            using (SqlConnection connection = new SqlConnection("Data Source=146.230.177.46;Initial Catalog=GroupWst9;User ID=GroupWst9;Password=87fnn"))
            {
                connection.Open();
                string checkQuery = "SELECT COUNT(*) FROM Items WHERE selectedItems = @ItemName";
                SqlCommand checkCommand = new SqlCommand(checkQuery, connection);
                checkCommand.Parameters.AddWithValue("@ItemName", itemName);
                int itemCount = (int)checkCommand.ExecuteScalar();
                return itemCount > 0;
            }
        }
        private void UpdateTotalCost()
        {
            TOTALCOST = AppleTot1 + NartjieTot1;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void Page_Load(object sender, EventArgs e)
        {


            using (SqlConnection connection = new SqlConnection("Data Source=146.230.177.46;Initial Catalog=GroupWst9;User ID=GroupWst9;Password=87fnn"))
            {
                connection.Open();
                string checkQuery = "SELECT Name, Customer_ID FROM CMW_Customer WHERE Email = @Email";
                SqlCommand checkCommand = new SqlCommand(checkQuery, connection);
                checkCommand.Parameters.AddWithValue("@Email", UniqueEmailTB.Text);

                // Execute the query and read the result
                SqlDataReader reader = checkCommand.ExecuteReader();

                if (reader.Read())
                {
                    string employeeName = reader["Name"].ToString();
                    string customerID = reader["Customer_ID"].ToString();
                    NameTextBox2.Text = employeeName; // Set the value in NameTextBox2
                    IDTextBox2.Text = customerID; // Set the value in IDTextBox2
                }

                reader.Close();
            }






            if (Context.User.Identity.IsAuthenticated)
            {
                UniqueEmailTB.Visible = false;
                NameTextBox2.Visible = false;
                IDTextBox2.Visible = false;
                Total_TextBox1.ReadOnly = true;
                UniqueEmailTB.Text = Context.User.Identity.Name;
            }


            if (!IsPostBack)
            {

                TOTALCOST = AppleTot + NartjieTot + GrapeTot + PeachTot + BananaTot + OrangeTot +
                FerreroTot + LongDonutTot + roundDonutTot + SnowballTot + blackForrestTot + VelvetTot +
                cheeseCakeTot + CustardCaramelTot + FruitSliceTot + HotCrossBunTot + CupCakeTot + CaramelcakeTot + SwizzRollTot + BlueberryTot + BarOnesliceTot +
                QueenCaketTot + PastryPuffTot + CreamBunsTot + PlainScortTot + QueencakeCheeseTot + RaisinScornTot + MeltingMomentTot + ChocolateMoueseTot + BarOneSquareTot +
                RedBull250Tot + RedbullTot + SmoothieTot + ReboostTot + StillWaterTot + SparkingWaterTot + smallFriedTot + LargeFriedTot + BeefburgerTot + HotDogTot + FruitSaladTot;

                Total_TextBox1.Text = TOTALCOST.ToString();
                if (IsItemInCart("Long Doughnut"))
                {
                    if (IsItemInCart("Long Doughnut"))
                    {
                        LongDonutPanel0.Visible = true;
                    }

                    LongDonutQuantityTextBox0.Text = AppleQuant.ToString();
                    longdonutprice = GetProductPrice("Long DoughnutLong Doughnut");
                    LongDonutPriceTextBox0.Text = Appleprice.ToString("0.00");
                    LongDonutTot = Appleprice * AppleQuant;
                    TOTALCOST += LongDonutTot;

                }
                else
                {
                    if (!IsItemInCart("Long Doughnut"))
                    {
                        ApplePanel.Visible = false;
                    }
                }
                if (IsItemInCart("Apple"))
                {
                    ApplePanel.Visible = true;
                    AppleQuantityTextBox1.Text = AppleQuant.ToString();
                    Appleprice = GetProductPrice("Apple");
                    ApplePriceTextBox2.Text = Appleprice.ToString("0.00");
                    AppleTot = Appleprice * AppleQuant;
                    TOTALCOST += AppleTot;

                }
                else
                {
                    if (!IsItemInCart("Apple"))
                    {
                        ApplePanel.Visible = false;
                    }
                }

                if (IsItemInCart("Nartjie"))
                {
                    NartjiePanel.Visible = true;
                    NartjieQuantityTextBox21.Text = NartjieQuant.ToString();

                    Nartjieprice = GetProductPrice("Vaartjie");
                    NartjiePriceTextBox12.Text = Nartjieprice.ToString("0.00");

                    // Calculate the total cost for Nartjies and add it to TOTALCOST
                    NartjieTot = Nartjieprice * NartjieQuant;
                    TOTALCOST += NartjieTot;
                }
                else
                {
                    if (!IsItemInCart("Nartjie"))
                    {
                        NartjiePanel.Visible = false;
                    }
                }


                if (IsItemInCart("Banana"))
                {
                    BananaPanel.Visible = true;
                    BananaQuantityTextBox19.Text = BananaQuant.ToString();

                    Bananaprice = GetProductPrice("Banana");
                    BananaPriceTextBox11.Text = Bananaprice.ToString("0.00");

                    BananaTot = Bananaprice * BananaQuant;
                    TOTALCOST += BananaTot;
                }
                else
                {
                    if (!IsItemInCart("Banana"))
                    {
                        BananaPanel.Visible = false;
                    }
                }

                if (IsItemInCart("Peach"))
                {
                    PlumPanel.Visible = true;
                    PeachQuantityTextBox15.Text = PlumQuant.ToString();

                    Peachprice = GetProductPrice("Peach");
                    PeachPriceTextBox9.Text = Peachprice.ToString("0.00");

                    PeachTot = Peachprice * PlumQuant;
                    TOTALCOST += PeachTot;
                }
                else
                {
                    if (!IsItemInCart("Peach"))
                    {
                        PlumPanel.Visible = false;
                    }
                }

                if (IsItemInCart("Grapes"))
                {
                    PearPanel.Visible = true;
                    PearQuantityTextBox13.Text = GrapeQuant.ToString();

                    grapeprice = GetProductPrice("Grapes");
                    PearPriceTextBox8.Text = grapeprice.ToString("0.00");

                    GrapeTot = grapeprice * GrapeQuant;
                    TOTALCOST += GrapeTot;
                }
                else
                {
                    if (!IsItemInCart("Grapes"))
                    {
                        PearPanel.Visible = false;
                    }
                }

                if (IsItemInCart("Orange"))
                {
                    OrangePanel.Visible = true;
                    OrangeQuantityTextBox17.Text = OrangeQuant.ToString();

                    Orangeprice = GetProductPrice("Orange");
                    OrangePriceTextBox10.Text = Orangeprice.ToString("0.00");

                    OrangeTot = Orangeprice * OrangeQuant;
                    TOTALCOST += OrangeTot;
                }
                else
                {
                    if (!IsItemInCart("Orange"))
                    {
                        OrangePanel.Visible = false;
                    }
                }


                if (IsItemInCart("Round Doughnut"))
                {
                    RoundDonutPanel.Visible = true;
                    roundDonutQuantityTextBox.Text = RoundDonutQuant.ToString();

                    rounddonutprice = GetProductPrice("Round Doughnut");
                    RoundDonutPriceTextBox.Text = rounddonutprice.ToString("0.00");

                    roundDonutTot = rounddonutprice * RoundDonutQuant;
                    TOTALCOST += roundDonutTot;
                }
                else
                {
                    if (!IsItemInCart("Round Doughnut"))
                    {
                        RoundDonutPanel.Visible = false;
                    }
                }

                if (IsItemInCart("Snowball"))
                {
                    SnowBallPanel1.Visible = true;
                    SnowballQuantityTextBox1.Text = SnowballQuant.ToString();

                    snowballprice = GetProductPrice("Snowball");
                    SnowBallPriceTextBox1.Text = snowballprice.ToString("0.00");

                    SnowballTot = snowballprice * SnowballQuant;
                    TOTALCOST += SnowballTot;
                }
                else
                {
                    if (!IsItemInCart("Snowball"))
                    {
                        SnowBallPanel1.Visible = false;
                    }
                }

                if (IsItemInCart("Black Forrest"))
                {
                    BlackForrestPanel3.Visible = true;
                    BlackForrestQuantityTextBox3.Text = BlackForrestQuant.ToString();

                    blackforrestprice = GetProductPrice("Black Forrest");
                    BlackForrestPriceTextBox3.Text = blackforrestprice.ToString("0.00");

                    blackForrestTot = blackforrestprice * BlackForrestQuant;
                    TOTALCOST += blackForrestTot;
                }
                else
                {
                    if (!IsItemInCart("Black Forrest"))
                    {
                        BlackForrestPanel3.Visible = false;
                    }
                }
                if (IsItemInCart("Velvet"))
                {
                    VelvetPanel4.Visible = true;
                    VelvetQuantityTextBox4.Text = VelvetQuant.ToString();

                    velvetprice = GetProductPrice("Red Velvet");
                    VelvetPriceTextBox4.Text = velvetprice.ToString("0.00");

                    VelvetTot = velvetprice * VelvetQuant;
                    TOTALCOST += VelvetTot;
                }
                else
                {
                    if (!IsItemInCart("Velvet"))
                    {
                        VelvetPanel4.Visible = false;
                    }
                }
                if (IsItemInCart("Ferrero Slice"))
                {
                    FerreroPanel2.Visible = true;
                    FerreroQuantityTextBox2.Text = FerreroQuant.ToString();

                    ferreroprice = GetProductPrice("Ferrero Slice");
                    FerreroPriceTextBox2.Text = ferreroprice.ToString("0.00");

                    FerreroTot = ferreroprice * FerreroQuant;
                    TOTALCOST += FerreroTot;
                }
                else
                {
                    if (!IsItemInCart("Ferrero Slice"))
                    {
                        FerreroPanel2.Visible = false;
                    }
                }
                if (IsItemInCart("CheeseCake"))
                {
                    cheeseCakepanel5.Visible = true;
                    cheeseCakeQuantityTextBox5.Text = QueenCakeQuant.ToString();
                    decimal cheeseCakePrice = GetProductPrice("Cheese Cake");
                    cheeseCakePriceTextBox5.Text = cheeseCakePrice.ToString("0.00");
                    cheeseCakeTot = cheeseCakePrice * QueenCakeQuant;
                    TOTALCOST += cheeseCakeTot;
                }
                else
                {
                    if (!IsItemInCart("CheeseCake"))
                    {
                        cheeseCakepanel5.Visible = false;
                    }
                }
                if (IsItemInCart("Custard Caramel Cake"))
                {
                    CustardcaramelPanel6.Visible = true;
                    CustardcaramelQuantityTextBox6.Text = PastryPuffQuant.ToString();
                    decimal custardCaramelPrice = GetProductPrice("Custard Caramel Cake");
                    CustardcaramelPriceTextBox6.Text = custardCaramelPrice.ToString("0.00");
                    CustardCaramelTot = custardCaramelPrice * PastryPuffQuant;
                    TOTALCOST += CustardCaramelTot;
                }
                else
                {
                    if (!IsItemInCart("Custard Caramel Cake"))
                    {
                        CustardcaramelPanel6.Visible = false;
                    }
                }
                if (IsItemInCart("Fruit Slice"))
                {
                    FruitSlicePanel7.Visible = true;
                    FruitSliceQuantityTextBox7.Text = CreamBunsQuant.ToString();
                    decimal fruitSlicePrice = GetProductPrice("Fruit Slice");
                    FruitSlicePriceTextBox7.Text = fruitSlicePrice.ToString("0.00");
                    FruitSliceTot = fruitSlicePrice * CreamBunsQuant;
                    TOTALCOST += FruitSliceTot;
                }
                else
                {
                    if (!IsItemInCart("Fruit Slice"))
                    {
                        FruitSlicePanel7.Visible = false;
                    }
                }
                if (IsItemInCart("Hot Cross Buns"))
                {
                    HotcrossbunPanel8.Visible = true;
                    HotcrossbunQuantityTextBox8.Text = PlainScornQuant.ToString();
                    decimal hotCrossBunPrice = GetProductPrice("Hot Cross Buns");
                    HotcrossbunPriceTextBox8.Text = hotCrossBunPrice.ToString("0.00");
                    HotCrossBunTot = hotCrossBunPrice * PlainScornQuant;
                    TOTALCOST += HotCrossBunTot;
                }
                else
                {
                    if (!IsItemInCart("Hot Cross Buns"))
                    {
                        HotcrossbunPanel8.Visible = false;
                    }
                }
                if (IsItemInCart("Cup Cakes"))
                {
                    CupcakePanel9.Visible = true;
                    CupcakeQuantityTextBox9.Text = QueencakeCheeseQuant.ToString();
                    decimal cupCakePrice = GetProductPrice("Cup Cakes");
                    CupcakePriceTextBox9.Text = cupCakePrice.ToString("0.00");
                    CupCakeTot = cupCakePrice * QueencakeCheeseQuant;
                    TOTALCOST += CupCakeTot;
                }
                else
                {
                    if (!IsItemInCart("Cup Cakes"))
                    {
                        CupcakePanel9.Visible = false;
                    }
                }
                if (IsItemInCart("Caramel Cake"))
                {
                    caramelcakePanel10.Visible = true;
                    CarameCakeQuantityTextBox10.Text = RaisinScornQuant.ToString();
                    decimal caramelCakePrice = GetProductPrice("Caramel Cake");
                    CaramelCakePriceTextBox10.Text = caramelCakePrice.ToString("0.00");
                    CaramelcakeTot = caramelCakePrice * RaisinScornQuant;
                    TOTALCOST += CaramelcakeTot;
                }
                else
                {
                    if (!IsItemInCart("Caramel Cake"))
                    {
                        caramelcakePanel10.Visible = false;
                    }
                }
                if (IsItemInCart("Swiss Roll"))
                {
                    SwizrollPanel11.Visible = true;
                    SwizrollQuantityTextBox11.Text = MeltingMomentQuant.ToString();
                    decimal swissRollPrice = GetProductPrice("Swiss Roll");
                    SwizzRollPriceTextBox11.Text = swissRollPrice.ToString("0.00");
                    SwizzRollTot = swissRollPrice * MeltingMomentQuant;
                    TOTALCOST += SwizzRollTot;
                }
                else
                {
                    if (!IsItemInCart("Swiss Roll"))
                    {
                        SwizrollPanel11.Visible = false;
                    }
                }
                if (IsItemInCart("Blueberry Slice"))
                {
                    blueberryPanel12.Visible = true;
                    BlueberryQuantityTextBox12.Text = ChocolateMoueseQuant.ToString();
                    decimal blueberrySlicePrice = GetProductPrice("Blueberry Slice");
                    BlueberryPriceTextBox12.Text = blueberrySlicePrice.ToString("0.00");
                    BlueberryTot = blueberrySlicePrice * ChocolateMoueseQuant;
                    TOTALCOST += BlueberryTot;
                }
                else
                {
                    if (!IsItemInCart("Blueberry Slice"))
                    {
                        blueberryPanel12.Visible = false;
                    }
                }
                if (IsItemInCart("Bar One Cake"))
                {
                    BarOnePanel.Visible = true;
                    BarOneQuantityTextBox13.Text = BarOneSquareQuant.ToString();
                    decimal barOnePrice = GetProductPrice("Bar One Cake");
                    BarOnePriceTextBox13.Text = barOnePrice.ToString("0.00");
                    BarOnesliceTot = barOnePrice * BarOneSquareQuant;
                    TOTALCOST += BarOnesliceTot;
                }
                else
                {
                    if (!IsItemInCart("Bar One Cake"))
                    {
                        BarOnePanel.Visible = false;
                    }
                }
                if (IsItemInCart("Queen Cakes"))
                {
                    QueenCakePanel14.Visible = true;
                    QueenCakeQuantityTextBox14.Text = QueenCakeQuant.ToString();
                    decimal queencakeprice = GetProductPrice("Queen Cakes");
                    QueenCakePriceTextBox14.Text = queencakeprice.ToString("0.00");
                    QueenCaketTot = queencakeprice * QueenCakeQuant;
                    TOTALCOST += QueenCaketTot;
                }
                else
                {
                    if (!IsItemInCart("Queen Cakes"))
                    {
                        QueenCakePanel14.Visible = false;
                    }
                }
                if (IsItemInCart("Pastry Puffs"))
                {
                    PastrypuffsPanel15.Visible = true;
                    PastrypuffsQuantityTextBox15.Text = PastryPuffQuant.ToString();
                    decimal pastrypuffsPrice = GetProductPrice("Pastry Puffs");
                    PastrypuffsPriceTextBox15.Text = pastrypuffsPrice.ToString("0.00");
                    decimal pastrypuffsTotal = pastrypuffsPrice * PastryPuffQuant;
                    TOTALCOST += pastrypuffsTotal;
                }
                else
                {
                    if (!IsItemInCart("Pastry Puffs"))
                    {
                        PastrypuffsPanel15.Visible = false;
                    }
                }
                if (IsItemInCart("Cream Buns"))
                {
                    CreamBunsPanel16.Visible = true;
                    CreamBunsQuantityTextBox16.Text = CreamBunsQuant.ToString();
                    decimal creamBunPrice = GetProductPrice("Cream Buns");
                    CreamBunsPriceTextBox16.Text = creamBunPrice.ToString("0.00");
                    decimal creamBunTotal = creamBunPrice * CreamBunsQuant;
                    TOTALCOST += creamBunTotal;
                }
                else
                {
                    if (!IsItemInCart("Cream Buns"))
                    {
                        CreamBunsPanel16.Visible = false;
                    }
                }
                if (IsItemInCart("Plain Scorn"))
                {
                    PlainScornPanel17.Visible = true;
                    PlainScornQuantityTextBox17.Text = PlainScornQuant.ToString();
                    decimal plainScornPrice = GetProductPrice("Plain Scorn");
                    PlainScornPriceTextBox17.Text = plainScornPrice.ToString("0.00");
                    decimal plainScornTotal = plainScornPrice * PlainScornQuant;
                    TOTALCOST += plainScornTotal;
                }
                else
                {
                    if (!IsItemInCart("Plain Scorn"))
                    {
                        PlainScornPanel17.Visible = false;
                    }
                }
                if (IsItemInCart("Queen Cakes(Cheesecake)"))
                {
                    QueenCakecheesePanel18.Visible = true;
                    QueenCakecheesQuantityTextBox18.Text = QueencakeCheeseQuant.ToString();
                    decimal queenCakesCheesePrice = GetProductPrice("Queen Cakes(Cheesecake)");
                    QueenCakecheesPriceTextBox18.Text = queenCakesCheesePrice.ToString("0.00");
                    decimal queenCakesCheeseTotal = queenCakesCheesePrice * QueencakeCheeseQuant;
                    TOTALCOST += queenCakesCheeseTotal;
                }
                else
                {
                    if (!IsItemInCart("Queen Cakes(Cheesecake)"))
                    {
                        QueenCakecheesePanel18.Visible = false;
                    }
                }
                if (IsItemInCart("Raisin Scorn"))
                {
                    RaisinscornPanel19.Visible = true;
                    RaisinscornQuantityTextBox19.Text = RaisinScornQuant.ToString();
                    decimal raisinScornPrice = GetProductPrice("Raisin Scorn");
                    RaisinscornPriceTextBox19.Text = raisinScornPrice.ToString("0.00");
                    decimal raisinScornTotal = raisinScornPrice * RaisinScornQuant;
                    TOTALCOST += raisinScornTotal;
                }
                else
                {
                    if (!IsItemInCart("Raisin Scorn"))
                    {
                        RaisinscornPanel19.Visible = false;
                    }
                }
                if (IsItemInCart("Melting Moment Cake"))
                {
                    meltingmomentPanel20.Visible = true;
                    meltingmomentQuantityTextBox20.Text = MeltingMomentQuant.ToString();
                    decimal meltingMomentPrice = GetProductPrice("Melting Moment Cake");
                    meltingmomentPriceTextBox20.Text = meltingMomentPrice.ToString("0.00");
                    decimal meltingMomentTotal = meltingMomentPrice * MeltingMomentQuant;
                    TOTALCOST += meltingMomentTotal;
                }

                else
                {
                    if (!IsItemInCart("Melting Moment Cake"))
                    {
                        meltingmomentPanel20.Visible = false;
                    }
                }




                if (IsItemInCart("Chocolate Cake"))
                {
                    chocolatecatePanel21.Visible = true;
                    chocolatemoseQuantityTextBox21.Text = ChocolateMoueseQuant.ToString();
                    decimal chocolateMouesPrice = GetProductPrice("Chocolate Cake");
                    chocolatemosePriceTextBox21.Text = chocolateMouesPrice.ToString("0.00");
                    decimal chocolateMouesTotal = chocolateMouesPrice * ChocolateMoueseQuant;
                    TOTALCOST += chocolateMouesTotal;
                }
                else
                {
                    if (!IsItemInCart("Chocolate Cake"))
                    {
                        chocolatecatePanel21.Visible = false;
                    }
                }


                if (IsItemInCart("Square Bar One Cake"))
                {
                    squarebaronePanel22.Visible = true;
                    squarebaroneQuantityTextBox22.Text = BarOneSquareQuant.ToString();
                    decimal barOneSquareSlicePrice = GetProductPrice("Square Bar One Cake");
                    squarebaronePriceTextBox22.Text = barOneSquareSlicePrice.ToString("0.00");
                    decimal barOneSquareSliceTotal = barOneSquareSlicePrice * BarOneSquareQuant;
                    TOTALCOST += barOneSquareSliceTotal;
                }
                else
                {
                    if (!IsItemInCart("Square Bar One Cake"))
                    {
                        squarebaronePanel22.Visible = false;
                    }
                }

                if (IsItemInCart("Small Fried Chips"))
                {
                    SmallfriedPanel29.Visible = true;
                    SmallfriedQuantityTextBox29.Text = SmallFriedQuant.ToString();
                    decimal smallFriedPrice = GetProductPrice("Small Fried Chips");
                    SmallfriedPriceTextBox29.Text = smallFriedPrice.ToString("0.00");
                    decimal smallFriedTotal = smallFriedPrice * SmallFriedQuant;
                    TOTALCOST += smallFriedTotal;
                }
                else
                {
                    if (!IsItemInCart("Small Fried Chips"))
                    {
                        SmallfriedPanel29.Visible = false;
                    }
                }



                if (IsItemInCart("Large Fried Chips"))
                {
                    LargeFriedPanel30.Visible = true;
                    LargeFriedQuantityTextBox30.Text = LargeFriedQuant.ToString();
                    decimal largeFriedsPrice = GetProductPrice("Large Fried Chips");
                    LargeFriedPriceTextBox30.Text = largeFriedsPrice.ToString("0.00");
                    decimal largeFriedsTotal = largeFriedsPrice * LargeFriedQuant;
                    TOTALCOST += largeFriedsTotal;
                }
                else
                {
                    if (!IsItemInCart("Large Fried Chips"))
                    {
                        LargeFriedPanel30.Visible = false;
                    }
                }


                if (IsItemInCart("Beef Burger"))
                {
                    BeefBurgerPanel31.Visible = true;
                    BeefBurgerQuantityTextBox31.Text = BeefburgerQuant.ToString();
                    decimal burgerPrice = GetProductPrice("Beef Burger");
                    BeefBurgerPriceTextBox31.Text = burgerPrice.ToString("0.00");
                    decimal burgerTotal = burgerPrice * BeefburgerQuant;
                    TOTALCOST += burgerTotal;
                }
                else
                {
                    if (!IsItemInCart("Beef Burger"))
                    {
                        BeefBurgerPanel31.Visible = false;
                    }
                }

                if (IsItemInCart("Hot Dog"))
                {
                    HotDogPanel32.Visible = true;
                    HotDogQuantityTextBox32.Text = HotDogQuant.ToString();
                    decimal hotdogsPrice = GetProductPrice("Hot Dog");
                    HotDogPriceTextBox32.Text = hotdogsPrice.ToString("0.00");
                    decimal hotdogsTotal = hotdogsPrice * HotDogQuant;
                    TOTALCOST += hotdogsTotal;
                }
                else
                {
                    if (!IsItemInCart("Hot Dog"))
                    {
                        HotDogPanel32.Visible = false;
                    }
                }

                if (IsItemInCart("Fruit Salad"))
                {
                    FruitSaladPanel33.Visible = true;
                    FruitSaladQuantityTextBox33.Text = FruitSaladQuant.ToString();
                    decimal fruitSaladPrice = GetProductPrice("Fruit Salad");
                    FruitSaladPriceTextBox33.Text = fruitSaladPrice.ToString("0.00");
                    decimal fruitSaladTotal = fruitSaladPrice * FruitSaladQuant;
                    TOTALCOST += fruitSaladTotal;
                }
                else
                {
                    if (!IsItemInCart("Fruit Salad"))
                    {
                        FruitSaladPanel33.Visible = false;
                    }
                }

                if (IsItemInCart("Red Bull 250ml"))
                {
                    redbull250Panel23.Visible = true;
                    redbull250QuantityTextBox23.Text = RedBull250Quant.ToString();
                    decimal redBull250Price = GetProductPrice("Red Bull 250ml");
                    redbull250PriceTextBox23.Text = redBull250Price.ToString("0.00");
                    decimal redBull250Total = redBull250Price * RedBull250Quant;
                    TOTALCOST += redBull250Total;
                }
                else
                {
                    if (!IsItemInCart("Red Bull 250ml"))
                    {
                        redbull250Panel23.Visible = false;
                    }
                }

                if (IsItemInCart("Red Bull"))
                {
                    RedbullPanel24.Visible = true;
                    RedbullQuantityTextBox24.Text = RedbullQuant.ToString();
                    decimal redBullSmallsPrice = GetProductPrice("Red Bull ");
                    RedbullPriceTextBox24.Text = redBullSmallsPrice.ToString("0.00");
                    decimal redBullSmallsTotal = redBullSmallsPrice * RedbullQuant;
                    TOTALCOST += redBullSmallsTotal;
                }
                else
                {
                    if (!IsItemInCart("Red Bull"))
                    {
                        RedbullPanel24.Visible = false;
                    }
                }
                if (IsItemInCart("Smoothie"))
                {
                    SmoothiePanel25.Visible = true;
                    SmoothieQuantityTextBox25.Text = SmoothieQuant.ToString();
                    decimal smoothiePrice = GetProductPrice("Smoothie");
                    SmoothiePriceTextBox25.Text = smoothiePrice.ToString("0.00");
                    decimal smoothieTotal = smoothiePrice * SmoothieQuant;
                    TOTALCOST += smoothieTotal;
                }
                else
                {
                    if (!IsItemInCart("Smoothie"))
                    {
                        SmoothiePanel25.Visible = false;
                    }
                }

                if (IsItemInCart("Rebooster"))
                {
                    reboostPanel26.Visible = true;
                    reboostQuantityTextBox26.Text = ReboostQuant.ToString();
                    decimal reboostPrice = GetProductPrice("Rebooster");
                    reboostPriceTextBox26.Text = reboostPrice.ToString("0.00");
                    decimal reboostTotal = reboostPrice * ReboostQuant;
                    TOTALCOST += reboostTotal;
                }
                else
                {
                    if (!IsItemInCart("Rebooster"))
                    {
                        reboostPanel26.Visible = false;
                    }
                }
                if (IsItemInCart("Still Water"))
                {
                    StillwaterPanel27.Visible = true;
                    StillwaterQuantityTextBox27.Text = StillWaterQuant.ToString();
                    decimal stillWaterPrice = GetProductPrice("Still Water");
                    StillwaterPriceTextBox27.Text = stillWaterPrice.ToString("0.00");
                    decimal stillWaterTotal = stillWaterPrice * StillWaterQuant;
                    TOTALCOST += stillWaterTotal;
                }
                else
                {
                    if (!IsItemInCart("Still Water"))
                    {
                        StillwaterPanel27.Visible = false;
                    }
                }
                if (IsItemInCart("Sparkling Water"))
                {
                    SparkingwaterPanel28.Visible = true;
                    SparkingwaterQuantityTextBox28.Text = SparkingWaterQuant.ToString();
                    decimal sparklingWaterPrice = GetProductPrice("Sparkling Water");
                    SparkingwaterPriceTextBox28.Text = sparklingWaterPrice.ToString("0.00");
                    decimal sparklingWaterTotal = sparklingWaterPrice * SparkingWaterQuant;
                    TOTALCOST += sparklingWaterTotal;
                }
                else
                {
                    if (!IsItemInCart("Sparkling Water"))
                    {
                        SparkingwaterPanel28.Visible = false;
                    }
                }
                if (IsItemInCart("Ice Cream Cone"))
                {
                    IcecreamCONEPanel34.Visible = true;
                    IcecreamCONEQuantityTextBox34.Text = IceCreamConeQuant.ToString();
                    decimal icecreamConePrice = GetProductPrice("Ice Cream Cone");
                    IcecreamCONEPriceTextBox34.Text = icecreamConePrice.ToString("0.00");
                    decimal icecreamConeTotal = icecreamConePrice * IceCreamConeQuant;
                    TOTALCOST += icecreamConeTotal;
                }
                else
                {
                    if (!IsItemInCart("Ice Cream Cone"))
                    {
                        IcecreamCONEPanel34.Visible = false;
                    }
                }
                if (IsItemInCart("Ice Cream Cone (2)"))
                {
                    IcecreamCUPPanel35.Visible = true;
                    IcecreamCUPQuantityTextBox35.Text = IceCreamCupQuant.ToString();
                    decimal cupIcecreamPrice = GetProductPrice("Ice Cream Cone (2)");
                    IcecreamCUPPriceTextBox35.Text = cupIcecreamPrice.ToString("0.00");
                    decimal cupIcecreamTotal = cupIcecreamPrice * IceCreamCupQuant;
                    TOTALCOST += cupIcecreamTotal;
                }
                else
                {
                    if (!IsItemInCart("Ice Cream Cone (2)"))
                    {
                        IcecreamCUPPanel35.Visible = false;
                    }
                }
                if (IsItemInCart("Ice Cream Cone(3)"))
                {
                    IcecreamOreosPanel36.Visible = true;
                    IcecreamOreosQuantityTextBox36.Text = IceCreamOreoQuant.ToString();
                    decimal oreoicecreamPrice = GetProductPrice("Ice Cream Cone(3)");
                    IcecreamOreosPriceTextBox36.Text = oreoicecreamPrice.ToString("0.00");
                    decimal oreoicecreamTotal = oreoicecreamPrice * IceCreamOreoQuant;
                    TOTALCOST += oreoicecreamTotal;
                }
                else
                {
                    if (!IsItemInCart("Ice Cream Cone(3)"))
                    {
                        IcecreamOreosPanel36.Visible = false;
                    }
                }

                Total_TextBox1.Text = TOTALCOST.ToString();




            }



        }



        protected void AddApples_Click(object sender, EventArgs e)
        {

        }


        public int GetProductQuantity(string productName)
        {
            int quantity = -1;

            using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
            {
                connection.Open();

                string checkQuery = "SELECT Quantity FROM Product WHERE Description = @ProductName";
                SqlCommand checkCommand = new SqlCommand(checkQuery, connection);
                checkCommand.Parameters.AddWithValue("@ProductName", productName);

                SqlDataReader reader = checkCommand.ExecuteReader();

                if (reader.Read())
                {
                    quantity = (int)reader["Quantity"];
                }

                reader.Close();
            }

            return quantity;
        }
        public void UpdateProductQuantity(string productName, int deductionAmount)
        {
            using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
            {
                connection.Open();

                string updateQuery = "UPDATE Product SET Quantity = Quantity - @DeductionAmount WHERE Description = @ProductName";
                SqlCommand updateCommand = new SqlCommand(updateQuery, connection);
                updateCommand.Parameters.AddWithValue("@DeductionAmount", deductionAmount);
                updateCommand.Parameters.AddWithValue("@ProductName", productName);

                // Execute the update command
                updateCommand.ExecuteNonQuery();
            }
        }





        private int GenerateUniqueOrderID()
        {
            int generatedOrderID = OrderID; // Assuming OrderID is the starting point.

            using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
            {
                connection.Open();

                string checkQuery = "SELECT MAX(OrderID) FROM ProductsOrder7";
                SqlCommand checkCommand = new SqlCommand(checkQuery, connection);

                object result = checkCommand.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    generatedOrderID = (int)result + 1;
                }
            }

            return generatedOrderID;
        }

        public void InsertProductOrder(int Quantity, string productName)
        {
            using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
            {
                connection.Open();

                string insertQuery = "INSERT INTO ProductsOrder7 (Product_ID, OrderID, Quantity, UnitPrice, SubTotal, Date) " +
                                      "VALUES (@Product_ID, @OrderID, @Quantity, @UnitPrice, @SubTotal, @Date)";


                SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                insertCommand.Parameters.AddWithValue("@Product_ID", GetProductID(productName));
                insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                insertCommand.Parameters.AddWithValue("@Quantity", Quantity);
                insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice(productName));
                insertCommand.Parameters.AddWithValue("@SubTotal", GetProductPrice(productName) * Quantity);
                insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);

                insertCommand.ExecuteNonQuery();
            }
        }


        protected void COnfirm_Click(object sender, EventArgs e)
        {
            OrderID = GenerateUniqueOrderID();
           

            if (ApplePanel.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                          "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";


                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Apple");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Apple"));
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Apple") * int.Parse(AppleQuantityTextBox1.Text));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    if (GetProductQuantity("Apple") >= decimal.Parse(AppleQuantityTextBox1.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", AppleQuantityTextBox1.Text);
                        UpdateProductQuantity("Apple", int.Parse(AppleQuantityTextBox1.Text));

                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailable";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "The insertion was successful.";
                    }
                    else
                    {
                        Label1.Text = "The insertion was not  successful.";
                    }
                }

                InsertProductOrder(int.Parse(AppleQuantityTextBox1.Text), "Apple");



            }
            if (BananaPanel.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                          "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Banana");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Banana"));
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Banana") * int.Parse(BananaQuantityTextBox19.Text));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    if (GetProductQuantity("Banana") >= decimal.Parse(BananaQuantityTextBox19.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", BananaQuantityTextBox19.Text);
                        UpdateProductQuantity("Banana", int.Parse(BananaQuantityTextBox19.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailable";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(BananaQuantityTextBox19.Text), "Banana");


            }

            if (PearPanel.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Grapes");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Grapes"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Grapes") * int.Parse(PearQuantityTextBox13.Text));
                    if (GetProductQuantity("Grapes") >= decimal.Parse(PearQuantityTextBox13.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", PearQuantityTextBox13.Text);
                        UpdateProductQuantity("Grapes", int.Parse(PearQuantityTextBox13.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailable";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(PearQuantityTextBox13.Text), "Grapes");
            }

            if (PlumPanel.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Peach");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Peach"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Peach") * int.Parse(PeachQuantityTextBox15.Text));
                    if (GetProductQuantity("Peach") >= decimal.Parse(PeachQuantityTextBox15.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", PeachQuantityTextBox15.Text);
                        UpdateProductQuantity("Peach", int.Parse(PeachQuantityTextBox15.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(PeachQuantityTextBox15.Text), "Peach");
            }

            if (OrangePanel.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Orange");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Orange"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Orange") * int.Parse(OrangeQuantityTextBox17.Text));
                    if (GetProductQuantity("Orange") >= decimal.Parse(OrangeQuantityTextBox17.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", OrangeQuantityTextBox17.Text);
                        UpdateProductQuantity("Orange", int.Parse(OrangeQuantityTextBox17.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(OrangeQuantityTextBox17.Text), "Orange");
            }

            if (NartjiePanel.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Nartjie");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Vaartjie"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Vaartjie") * int.Parse(NartjieQuantityTextBox21.Text));
                    if (GetProductQuantity("Vaartjie") >= decimal.Parse(NartjieQuantityTextBox21.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", NartjieQuantityTextBox21.Text);
                        UpdateProductQuantity("Vaartjie", int.Parse(NartjieQuantityTextBox21.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(NartjieQuantityTextBox21.Text), "Vaartjie");
            }

            if (RoundDonutPanel.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";
                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Round Doughnut");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Round Doughnut"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Round Doughnut") * int.Parse(roundDonutQuantityTextBox.Text));
                    if (GetProductQuantity("Round Doughnut") >= decimal.Parse(roundDonutQuantityTextBox.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", roundDonutQuantityTextBox.Text);
                        UpdateProductQuantity("Round Doughnut", int.Parse(roundDonutQuantityTextBox.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(roundDonutQuantityTextBox.Text), "Round Doughnut");
            }

            if (LongDonutPanel0.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                          "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";
                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Long Doughnut");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Long Doughnut"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Long Doughnut") * int.Parse(LongDonutQuantityTextBox0.Text));
                    if (GetProductQuantity("Long Doughnut") >= decimal.Parse(LongDonutQuantityTextBox0.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", LongDonutQuantityTextBox0.Text);
                        UpdateProductQuantity("Long Doughnut", int.Parse(LongDonutQuantityTextBox0.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(LongDonutQuantityTextBox0.Text), "Long Doughnut");
            }

            if (SnowBallPanel1.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Snowball");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Snowball"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Snowball") * int.Parse(SnowballQuantityTextBox1.Text));
                    if (GetProductQuantity("Snowball") >= decimal.Parse(SnowballQuantityTextBox1.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", SnowballQuantityTextBox1.Text);
                        UpdateProductQuantity("Snowball", int.Parse(SnowballQuantityTextBox1.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(SnowballQuantityTextBox1.Text), "Snowball");
            }

            if (FerreroPanel2.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Ferrero Slice");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Ferrero Slice"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Ferrero Slice") * int.Parse(FerreroQuantityTextBox2.Text));
                    if (GetProductQuantity("Ferrero Slice") >= decimal.Parse(FerreroQuantityTextBox2.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", FerreroQuantityTextBox2.Text);
                        UpdateProductQuantity("Ferrero Slice", int.Parse(FerreroQuantityTextBox2.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(FerreroQuantityTextBox2.Text), "Ferrero Slice");
            }

            if (BlackForrestPanel3.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Black Forrest");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Black Forrest"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Black Forrest") * int.Parse(BlackForrestQuantityTextBox3.Text));
                    if (GetProductQuantity("Black Forrest") >= decimal.Parse(BlackForrestQuantityTextBox3.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", BlackForrestQuantityTextBox3.Text);
                        UpdateProductQuantity("Black Forrest", int.Parse(BlackForrestQuantityTextBox3.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(BlackForrestQuantityTextBox3.Text), "Black Forrest");
            }

            if (VelvetPanel4.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Red Velvet");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Red Velvet"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Red Velvet") * int.Parse(VelvetQuantityTextBox4.Text));
                    if (GetProductQuantity("Red Velvet") >= decimal.Parse(VelvetQuantityTextBox4.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", VelvetQuantityTextBox4.Text);
                        UpdateProductQuantity("Red Velvet", int.Parse(VelvetQuantityTextBox4.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(VelvetQuantityTextBox4.Text), "Red Velvet");
            }

            if (cheeseCakepanel5.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Cheese Cake");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Cheese Cake"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Cheese Cake") * int.Parse(cheeseCakeQuantityTextBox5.Text));
                    if (GetProductQuantity("Cheese Cake") >= decimal.Parse(cheeseCakeQuantityTextBox5.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", cheeseCakeQuantityTextBox5.Text);
                        UpdateProductQuantity("Cheese Cake", int.Parse(cheeseCakeQuantityTextBox5.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(cheeseCakeQuantityTextBox5.Text), "Cheese Cake");
            }

            if (CustardcaramelPanel6.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Custard Caramel Cake");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Custard Caramel Cake"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Custard Caramel Cake") * int.Parse(CustardcaramelQuantityTextBox6.Text));
                    if (GetProductQuantity("Custard Caramel Cake") >= decimal.Parse(CustardcaramelQuantityTextBox6.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", CustardcaramelQuantityTextBox6.Text);
                        UpdateProductQuantity("Custard Caramel Cake", int.Parse(CustardcaramelQuantityTextBox6.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(CustardcaramelQuantityTextBox6.Text), "Custard Caramel Cake");
            }

            if (FruitSlicePanel7.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Fruit Slice ");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Fruit Slice "));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Fruit Slice") * int.Parse(FruitSliceQuantityTextBox7.Text));
                    if (GetProductQuantity("Fruit Slice ") >= decimal.Parse(FruitSliceQuantityTextBox7.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", FruitSliceQuantityTextBox7.Text);
                        UpdateProductQuantity("Fruit Slice", int.Parse(FruitSliceQuantityTextBox7.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(FruitSliceQuantityTextBox7.Text), "Fruit Slice");
            }

            if (HotcrossbunPanel8.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Hot Cross Buns");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Hot Cross Buns"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Hot Cross Buns") * int.Parse(HotcrossbunQuantityTextBox8.Text));
                    if (GetProductQuantity("Hot Cross Buns") >= decimal.Parse(HotcrossbunQuantityTextBox8.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", HotcrossbunQuantityTextBox8.Text);
                        UpdateProductQuantity("Hot Cross Buns", int.Parse(HotcrossbunQuantityTextBox8.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(HotcrossbunQuantityTextBox8.Text), "Hot Cross Buns");
            }

            if (CupcakePanel9.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Cup Cakes");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Cup Cakes"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Cup Cakes") * int.Parse(CupcakeQuantityTextBox9.Text));
                    if (GetProductQuantity("Cup Cakes") >= decimal.Parse(CupcakeQuantityTextBox9.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", CupcakeQuantityTextBox9.Text);
                        UpdateProductQuantity("Cup Cakes", int.Parse(CupcakeQuantityTextBox9.Text));

                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(CupcakeQuantityTextBox9.Text), "Cup Cakes");
            }

            if (caramelcakePanel10.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Caramel Cake");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Caramel Cake"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Caramel Cake") * int.Parse(CarameCakeQuantityTextBox10.Text));
                    if (GetProductQuantity("Caramel Cake") >= decimal.Parse(CarameCakeQuantityTextBox10.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", CarameCakeQuantityTextBox10.Text);
                        UpdateProductQuantity("Caramel Cake", int.Parse(CarameCakeQuantityTextBox10.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(CarameCakeQuantityTextBox10.Text), "Caramel Cake");
            }

            if (SwizrollPanel11.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Swiss Roll");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Swiss Roll"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Swiss Roll") * int.Parse(SwizrollQuantityTextBox11.Text));
                    if (GetProductQuantity("Swiss Roll") >= decimal.Parse(SwizrollQuantityTextBox11.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", SwizrollQuantityTextBox11.Text);
                        UpdateProductQuantity("Swiss Roll", int.Parse(SwizrollQuantityTextBox11.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(SwizrollQuantityTextBox11.Text), "Swiss Roll");
            }

            if (blueberryPanel12.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Blueberry Slice");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Blueberry Slice"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Blueberry Slice") * int.Parse(BlueberryQuantityTextBox12.Text));
                    if (GetProductQuantity("Blueberry Slice") >= decimal.Parse(BlueberryQuantityTextBox12.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", BlueberryQuantityTextBox12.Text);
                        UpdateProductQuantity("Blueberry Slice", int.Parse(BlueberryQuantityTextBox12.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(BlueberryQuantityTextBox12.Text), "Blueberry Slice");
            }

            if (BarOnePanel.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Bar One Cake");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Bar One Cake"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Bar One Cake") * int.Parse(BarOneQuantityTextBox13.Text));
                    if (GetProductQuantity("Bar One Cake") >= decimal.Parse(BarOneQuantityTextBox13.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", BarOneQuantityTextBox13.Text);
                        UpdateProductQuantity("Bar One Cake", int.Parse(BarOneQuantityTextBox13.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(BarOneQuantityTextBox13.Text), "Bar One Cake");
            }

            if (QueenCakePanel14.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Queen Cakes");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Queen Cakes"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Queen Cakes") * int.Parse(QueenCakeQuantityTextBox14.Text));
                    if (GetProductQuantity("Queen Cakes") >= decimal.Parse(QueenCakeQuantityTextBox14.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", QueenCakeQuantityTextBox14.Text);
                        UpdateProductQuantity("Queen Cakes", int.Parse(QueenCakeQuantityTextBox14.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(QueenCakeQuantityTextBox14.Text), "Queen Cakes");
            }

            if (PastrypuffsPanel15.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                           "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Pastry Puffs");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Pastry Puffs"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Pastry Puffs") * int.Parse(PastrypuffsQuantityTextBox15.Text));
                    if (GetProductQuantity("Pastry Puffs") >= decimal.Parse(PastrypuffsQuantityTextBox15.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", PastrypuffsQuantityTextBox15.Text);
                        UpdateProductQuantity("Pastry Puffs", int.Parse(PastrypuffsQuantityTextBox15.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(PastrypuffsQuantityTextBox15.Text), "Pastry Puffs");
            }

            if (CreamBunsPanel16.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Cream Buns");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Cream Buns"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Cream Buns") * int.Parse(CreamBunsQuantityTextBox16.Text));
                    if (GetProductQuantity("Cream Buns") >= decimal.Parse(CreamBunsQuantityTextBox16.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", CreamBunsQuantityTextBox16.Text);
                        UpdateProductQuantity("Cream Buns", int.Parse(CreamBunsQuantityTextBox16.Text));

                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(CreamBunsQuantityTextBox16.Text), "Cream Buns");
            }

            if (PlainScornPanel17.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                          "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Plain Scorn");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Plain Scorn"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Plain Scorn") * int.Parse(PlainScornQuantityTextBox17.Text));
                    if (GetProductQuantity("Plain Scorn") >= decimal.Parse(PlainScornQuantityTextBox17.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", PlainScornQuantityTextBox17.Text);
                        UpdateProductQuantity("Plain Scorn", int.Parse(PlainScornQuantityTextBox17.Text));

                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(PlainScornQuantityTextBox17.Text), "Plain Scorn");
            }

            if (QueenCakecheesePanel18.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Queen Cakes(Cheesecake)");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Queen Cakes(Cheesecake)"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Queen Cakes(Cheesecake)") * int.Parse(QueenCakecheesQuantityTextBox18.Text));
                    if (GetProductQuantity("Queen Cakes(Cheesecake)") >= decimal.Parse(QueenCakecheesQuantityTextBox18.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", QueenCakecheesQuantityTextBox18.Text);
                        UpdateProductQuantity("Queen Cakes(Cheesecake)", int.Parse(QueenCakecheesQuantityTextBox18.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(QueenCakecheesQuantityTextBox18.Text), "Queen Cakes(Cheesecake");
            }

            if (RaisinscornPanel19.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Raisin scorn");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Raisin Scorn"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Raisin scorn") * int.Parse(RaisinscornQuantityTextBox19.Text));
                    if (GetProductQuantity("Raisin scorn") >= decimal.Parse(RaisinscornQuantityTextBox19.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", RaisinscornQuantityTextBox19.Text);
                        UpdateProductQuantity("Raisin scorn", int.Parse(RaisinscornQuantityTextBox19.Text));

                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(RaisinscornQuantityTextBox19.Text), "Raisin scorn");
            }

            if (meltingmomentPanel20.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                          "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Melting Moment Cake");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Melting Moment Cake"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Melting Moment Cake") * int.Parse(meltingmomentQuantityTextBox20.Text));
                    if (GetProductQuantity("Melting Moment Cake") >= decimal.Parse(meltingmomentQuantityTextBox20.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", meltingmomentQuantityTextBox20.Text);
                        UpdateProductQuantity("Melting Moment Cake", int.Parse(chocolatemoseQuantityTextBox21.Text));

                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(chocolatemoseQuantityTextBox21.Text), "Melting Moment Cake");
            }

            if (chocolatecatePanel21.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Chocolate Cake");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Chocolate Cake"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Chocolate Cake") * int.Parse(chocolatemoseQuantityTextBox21.Text));
                    if (GetProductQuantity("Chocolate Cake") >= decimal.Parse(chocolatemoseQuantityTextBox21.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", chocolatemoseQuantityTextBox21.Text);
                        UpdateProductQuantity("Chocolate Cake", int.Parse(chocolatemoseQuantityTextBox21.Text));

                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(chocolatemoseQuantityTextBox21.Text), "Chocolate Cake");
            }

            if (squarebaronePanel22.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Square Bar One Cake");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Square Bar One Cake"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Square Bar One Cake") * int.Parse(squarebaroneQuantityTextBox22.Text));
                    if (GetProductQuantity("Square Bar One Cake") >= decimal.Parse(squarebaroneQuantityTextBox22.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", squarebaroneQuantityTextBox22.Text);
                        UpdateProductQuantity("Square Bar One Cake", int.Parse(squarebaroneQuantityTextBox22.Text));

                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(squarebaroneQuantityTextBox22.Text), "Square Bar One Cake");
            }

            if (redbull250Panel23.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Red Bull 250ml ");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Red Bull 250ml "));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Red Bull 250ml") * int.Parse(redbull250QuantityTextBox23.Text));
                    if (GetProductQuantity("Red Bull 250ml ") >= decimal.Parse(redbull250QuantityTextBox23.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", redbull250QuantityTextBox23.Text);
                        UpdateProductQuantity("Red Bull 250ml", int.Parse(redbull250QuantityTextBox23.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(redbull250QuantityTextBox23.Text), "Red Bull 250ml");
            }

            if (RedbullPanel24.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                          "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Red Bull");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Red Bull"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Red Bull") * int.Parse(RedbullQuantityTextBox24.Text));
                    if (GetProductQuantity("Red Bull") >= decimal.Parse(RedbullQuantityTextBox24.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", RedbullQuantityTextBox24.Text);
                        UpdateProductQuantity("Red Bull", int.Parse(RedbullQuantityTextBox24.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(RedbullQuantityTextBox24.Text), "Red Bull");
            }

            if (SmoothiePanel25.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                         "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Smoothie");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Smoothie"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Smoothie") * int.Parse(SmoothieQuantityTextBox25.Text));
                    if (GetProductQuantity("Smoothie") >= decimal.Parse(SmoothieQuantityTextBox25.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", SmoothieQuantityTextBox25.Text);
                        UpdateProductQuantity("Smoothie", int.Parse(SmoothieQuantityTextBox25.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(SmoothieQuantityTextBox25.Text), "Smoothie");
            }

            if (reboostPanel26.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Rebooster");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Rebooster"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Rebooster") * int.Parse(reboostQuantityTextBox26.Text));
                    if (GetProductQuantity("Rebooster") >= decimal.Parse(reboostQuantityTextBox26.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", reboostQuantityTextBox26.Text);
                        UpdateProductQuantity("Rebooster", int.Parse(reboostQuantityTextBox26.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(reboostQuantityTextBox26.Text), "Rebooster");
            }

            if (StillwaterPanel27.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                           "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Still Water");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Still Water"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Still Water") * int.Parse(StillwaterQuantityTextBox27.Text));
                    if (GetProductQuantity("Still Water") >= decimal.Parse(StillwaterQuantityTextBox27.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", StillwaterQuantityTextBox27.Text);
                        UpdateProductQuantity("Still Water", int.Parse(StillwaterQuantityTextBox27.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(StillwaterQuantityTextBox27.Text), "Still Water");
            }

            if (SparkingwaterPanel28.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Sparkling Water");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Sparkling Water"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Sparkling Water") * int.Parse(SparkingwaterQuantityTextBox28.Text));
                    if (GetProductQuantity("Sparkling Water") >= decimal.Parse(SparkingwaterQuantityTextBox28.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", SparkingwaterQuantityTextBox28.Text);
                        UpdateProductQuantity("Sparkling Water", int.Parse(SparkingwaterQuantityTextBox28.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(SparkingwaterQuantityTextBox28.Text), "Sparkling Water");
            }

            if (SmallfriedPanel29.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Small Fried Chips");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Small Fried Chips"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Small Fried Chips") * int.Parse(SmallfriedQuantityTextBox29.Text));
                    if (GetProductQuantity("Small Fried Chips") >= decimal.Parse(SmallfriedQuantityTextBox29.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", SmallfriedQuantityTextBox29.Text);
                        UpdateProductQuantity("Small Fried Chips", int.Parse(SmallfriedQuantityTextBox29.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(SmallfriedQuantityTextBox29.Text), "Small Fried Chips");
            }

            if (LargeFriedPanel30.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Large Fried Chips");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Large Fried Chips"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Large Fried Chips") * int.Parse(LargeFriedQuantityTextBox30.Text));
                    if (GetProductQuantity("Large Fried Chips") >= decimal.Parse(LargeFriedQuantityTextBox30.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", LargeFriedQuantityTextBox30.Text);
                        UpdateProductQuantity("Large Fried Chips", int.Parse(LargeFriedQuantityTextBox30.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(LargeFriedQuantityTextBox30.Text), "Large Fried Chips");
            }

            if (BeefBurgerPanel31.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Beef Burger");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Beef Burger"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Beef Burger") * int.Parse(BeefBurgerQuantityTextBox31.Text));
                    if (GetProductQuantity("Beef Burger") >= decimal.Parse(BeefBurgerQuantityTextBox31.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", BeefBurgerQuantityTextBox31.Text);
                        UpdateProductQuantity("Beef Burger", int.Parse(BeefBurgerQuantityTextBox31.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(BeefBurgerQuantityTextBox31.Text), "Beef Burge");
            }

            if (HotDogPanel32.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Hot Dog");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Hot Dog"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Hot Dog") * int.Parse(HotDogQuantityTextBox32.Text));
                    if (GetProductQuantity("Hot Dog") >= decimal.Parse(HotDogQuantityTextBox32.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", HotDogQuantityTextBox32.Text);
                        UpdateProductQuantity("Hot Dog", int.Parse(HotDogQuantityTextBox32.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(HotDogQuantityTextBox32.Text), "Hot Dog");
            }

            if (FruitSaladPanel33.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                          "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Fruit Salad");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Fruit Salad"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Fruit Salad") * int.Parse(FruitSaladQuantityTextBox33.Text));
                    if (GetProductQuantity("Fruit Salad") >= decimal.Parse(FruitSaladQuantityTextBox33.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", FruitSaladQuantityTextBox33.Text);
                        UpdateProductQuantity("Fruit Salad", int.Parse(FruitSaladQuantityTextBox33.Text));

                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(FruitSaladQuantityTextBox33.Text), "Fruit Salad");
            }

            if (IcecreamCONEPanel34.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                       "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Ice Cream Cone");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Ice Cream Cone"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Ice Cream Cone") * int.Parse(IcecreamCONEQuantityTextBox34.Text));
                    if (GetProductQuantity("Ice Cream Cone") >= decimal.Parse(IcecreamCONEQuantityTextBox34.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", IcecreamCONEQuantityTextBox34.Text);
                        UpdateProductQuantity("Ice Cream Cone", int.Parse(IcecreamCONEQuantityTextBox34.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(IcecreamCONEQuantityTextBox34.Text), "Ice Cream Cone");
            }

            if (IcecreamCUPPanel35.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Ice Cream Cone (2)");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Ice Cream Cone (2)"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Ice Cream Cone (2)") * int.Parse(IcecreamCUPQuantityTextBox35.Text));
                    if (GetProductQuantity("Ice Cream Cone (2)") >= decimal.Parse(IcecreamCUPQuantityTextBox35.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", IcecreamCUPQuantityTextBox35.Text);
                        UpdateProductQuantity("Ice Cream Cone (2)", int.Parse(IcecreamCUPQuantityTextBox35.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(IcecreamCUPQuantityTextBox35.Text), "Ice Cream Cone (2)");
            }

            if (IcecreamOreosPanel36.Visible == true)
            {
                using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO OrderCust1 (Name, Customer_ID, OrderID, Items, Price, Date, UnitPrice, Quantity) " +
                                        "VALUES (@Name, @CustomerID, @OrderID, @Items, @Price, @Date, @UnitPrice,@Quantity)";


                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                    insertCommand.Parameters.AddWithValue("@Name", NameTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@CustomerID", IDTextBox2.Text);
                    insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                    insertCommand.Parameters.AddWithValue("@Items", "Ice Cream Cone(3)");
                    insertCommand.Parameters.AddWithValue("@Price", GetProductPrice("Ice Cream Cone(3)"));
                    insertCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                    insertCommand.Parameters.AddWithValue("@UnitPrice", GetProductPrice("Ice Cream Cone(3)") * int.Parse(IcecreamOreosQuantityTextBox36.Text));
                    if (GetProductQuantity("Ice Cream Cone(3)") >= decimal.Parse(IcecreamOreosQuantityTextBox36.Text))
                    {
                        insertCommand.Parameters.AddWithValue("@Quantity", IcecreamOreosQuantityTextBox36.Text);
                        UpdateProductQuantity("Ice Cream Cone(3)", int.Parse(IcecreamOreosQuantityTextBox36.Text));
                    }
                    else
                    {
                        Label1.Text = "Quantity is unavailble";
                    }
                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // The insertion was successful.
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                    else
                    {
                        Label1.Text = "Your Order will be ready in few minutes.";
                    }
                }
                InsertProductOrder(int.Parse(IcecreamOreosQuantityTextBox36.Text), "Ice Cream Cone(3)");
            }


            using (SqlConnection connection = new SqlConnection("Data Source = 146.230.177.46; Initial Catalog = GroupWst9; User ID = GroupWst9; Password = 87fnn"))
            {
                connection.Open();

                string insertQuery = "INSERT INTO OderCust2 (orderTotal, OrderID,Status) " +
                                     "VALUES (@OrderTotal, @OrderID, @Status)";

                SqlCommand insertCommand = new SqlCommand(insertQuery, connection);

                insertCommand.Parameters.AddWithValue("@OrderTotal", decimal.Parse(Total_TextBox1.Text));
                insertCommand.Parameters.AddWithValue("@OrderID", OrderID);
                insertCommand.Parameters.AddWithValue("@Status", "Pending");

                int rowsAffected = insertCommand.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    // The insertion was successful.
                    Label1.Text = "Your Order will be ready in few minutes.";
                }
                else
                {
                    Label1.Text = "Your Order will be ready in few minutes.";
                }

            }



        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void CancelItem(string itemName)
        {
            using (SqlConnection connection = new SqlConnection("Data Source=146.230.177.46;Initial Catalog=GroupWst9;User ID=GroupWst9;Password=87fnn"))
            {
                connection.Open();

                string deleteQuery = "DELETE FROM Items WHERE selectedItems = @ItemName";
                SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection);
                deleteCommand.Parameters.AddWithValue("@ItemName", itemName);
                deleteCommand.ExecuteNonQuery();
            }
        }


        protected void cancelApple_Click(object sender, EventArgs e)
        {

            AppleQuant = 0;

            CancelItem("Apple");
            AppleTot = decimal.Parse(ApplePriceTextBox2.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - AppleTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("AppleButtonClicked");
            ApplePanel.Visible = false;
        }

        protected void cancelPear_Click(object sender, EventArgs e)
        {
            GrapeQuant = 1;
            CancelItem("Grapes");
            GrapeTot = decimal.Parse(PearPriceTextBox8.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - GrapeTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("GrapesButton1Clicked");
            PearPanel.Visible = false;

        }

        protected void cancelPeach_Click(object sender, EventArgs e)
        {
            PlumPanel.Visible = false;
            PlumQuant = 1;
            CancelItem("Peach");
            PeachTot = decimal.Parse(PeachPriceTextBox9.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - PeachTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("PlumButton1Clicked");
        }

        protected void cancelOrange_Click(object sender, EventArgs e)
        {
            OrangePanel.Visible = false;
            OrangeQuant = 1;
            CancelItem("Orange");
            OrangeTot = decimal.Parse(OrangePriceTextBox10.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - OrangeTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("ImageButton4Clicked");

        }

        protected void cancelBanana_Click(object sender, EventArgs e)
        {
            BananaPanel.Visible = false;
            BananaQuant = 1;
            CancelItem("Banana");
            BananaTot = decimal.Parse(BananaPriceTextBox11.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - BananaTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("ButtonNartjieClicked");

        }

        protected void cancelNartjie_Click(object sender, EventArgs e)
        {
            NartjiePanel.Visible = false;
            NartjieQuant = 1;
            CancelItem("Nartjie");
            NartjieTot = decimal.Parse(NartjiePriceTextBox12.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - NartjieTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("NartjieButtonClicked");

        }

        protected void AddApples5_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PearQuantityTextBox13.Text);
            newQuant++;
            PearQuantityTextBox13.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Grapes");
            GrapeTot = Price * newQuant;
            PearPriceTextBox8.Text = GrapeTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();


        }

        protected void SubPear_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PearQuantityTextBox13.Text);
            if (newQuant > 1)
            {
                newQuant--;
                PearQuantityTextBox13.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Grapes");
                GrapeTot = Price * newQuant;
                PearPriceTextBox8.Text = GrapeTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void AddApples6_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PeachQuantityTextBox15.Text);
            newQuant++;
            PeachQuantityTextBox15.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Peach");
            PeachTot = Price * newQuant;
            PeachPriceTextBox9.Text = PeachTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void SubPeach_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PeachQuantityTextBox15.Text);

            if (newQuant > 0)
            {

                newQuant++;
                PeachQuantityTextBox15.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Peach");
                PeachTot = Price * newQuant;
                PeachPriceTextBox9.Text = PeachTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void CustardcaramelAddButton1_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(CustardcaramelQuantityTextBox6.Text);

            if (newQuant > 0)
            {

                newQuant++;
                CustardcaramelQuantityTextBox6.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Custard Caramel Cake");
                CustardCaramelTot = Price * newQuant;
                CustardcaramelPriceTextBox6.Text = CustardCaramelTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void HotcrossbunAddButton3_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(HotcrossbunQuantityTextBox8.Text);

            if (newQuant > 0)
            {

                newQuant++;
                HotcrossbunQuantityTextBox8.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Hot Cross Buns");
                HotCrossBunTot = Price * newQuant;
                HotcrossbunPriceTextBox8.Text = HotCrossBunTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }


        protected void SwizrollAddButton6_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(SwizrollQuantityTextBox11.Text);

            if (newQuant > 0)
            {

                newQuant++;
                SwizrollQuantityTextBox11.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Swiss Roll");
                SwizzRollTot = Price * newQuant;
                SwizzRollPriceTextBox11.Text = SwizzRollTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void BarOneAddButton8_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BarOneQuantityTextBox13.Text);

            if (newQuant > 0)
            {

                newQuant++;
                BarOneQuantityTextBox13.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Bar One Cake");
                BarOnesliceTot = Price * newQuant;
                BarOnePriceTextBox13.Text = BarOnesliceTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void QueenCakeAddButton9_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(QueenCakeQuantityTextBox14.Text);

            if (newQuant > 0)
            {

                newQuant++;
                QueenCakeQuantityTextBox14.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Queen Cakes");
                QueenCaketTot = Price * newQuant;
                QueenCakePriceTextBox14.Text = QueenCaketTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void PastrypuffsAddButton10_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PastrypuffsQuantityTextBox15.Text);

            if (newQuant > 0)
            {

                newQuant++;
                PastrypuffsQuantityTextBox15.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Pastry Puffs");
                PastryPuffTot = Price * newQuant;
                PastrypuffsPriceTextBox15.Text = PastryPuffTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void CreamBunsAddButton11_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(CreamBunsQuantityTextBox16.Text);

            if (newQuant > 0)
            {

                newQuant++;
                CreamBunsQuantityTextBox16.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Cream Buns");
                CreamBunsTot = Price * newQuant;
                CreamBunsPriceTextBox16.Text = CreamBunsTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void PlainScornAddButton12_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PlainScornQuantityTextBox17.Text);

            if (newQuant > 0)
            {

                newQuant++;
                PlainScornQuantityTextBox17.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Plain Scorn");
                PlainScortTot = Price * newQuant;
                PlainScornPriceTextBox17.Text = PlainScortTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void QueenCakecheesAddButton13_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(QueenCakecheesQuantityTextBox18.Text);

            if (newQuant > 0)
            {

                newQuant++;
                QueenCakecheesQuantityTextBox18.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Queen Cakes(Cheesecake)");
                QueencakeCheeseTot = Price * newQuant;
                QueenCakecheesPriceTextBox18.Text = QueencakeCheeseTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void RaisinscornAddButton14_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(RaisinscornQuantityTextBox19.Text);

            if (newQuant > 0)
            {

                newQuant++;
                RaisinscornQuantityTextBox19.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Raisin Scorn");
                RaisinScornTot = Price * newQuant;
                RaisinscornPriceTextBox19.Text = RaisinScornTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void meltingmomentAddButton15_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(meltingmomentQuantityTextBox20.Text);

            if (newQuant > 0)
            {

                newQuant++;
                meltingmomentQuantityTextBox20.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Melting Moment Cake");
                MeltingMomentTot = Price * newQuant;
                meltingmomentPriceTextBox20.Text = MeltingMomentTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void chocolatemoseAddButton16_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(chocolatemoseQuantityTextBox21.Text);

            if (newQuant > 0)
            {

                newQuant++;
                chocolatemoseQuantityTextBox21.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Chocolate Cake");
                ChocolateMoueseTot = Price * newQuant;
                chocolatemosePriceTextBox21.Text = ChocolateMoueseTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void squarebaroneAddButton17_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(squarebaroneQuantityTextBox22.Text);

            if (newQuant > 0)
            {

                newQuant++;
                squarebaroneQuantityTextBox22.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Square Bar One Cake");
                BarOneSquareTot = Price * newQuant;
                squarebaronePriceTextBox22.Text = BarOneSquareTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void redbull250AddButton18_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(redbull250QuantityTextBox23.Text);

            if (newQuant > 0)
            {

                newQuant++;
                redbull250QuantityTextBox23.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Red Bull 250ml");
                RedBull250Tot = Price * newQuant;
                redbull250PriceTextBox23.Text = RedBull250Tot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void RedbullAddButton19_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(RedbullQuantityTextBox24.Text);

            if (newQuant > 0)
            {

                newQuant++;
                RedbullQuantityTextBox24.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Red Bull");
                RedbullTot = Price * newQuant;
                RedbullPriceTextBox24.Text = RedbullTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void SmoothieAddButton20_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(SmoothieQuantityTextBox25.Text);

            if (newQuant > 0)
            {

                newQuant++;
                SmoothieQuantityTextBox25.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Smoothie");
                SmoothieTot = Price * newQuant;
                SmoothiePriceTextBox25.Text = SmoothieTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void reboostAddButton21_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(reboostQuantityTextBox26.Text);

            if (newQuant > 0)
            {

                newQuant++;
                reboostQuantityTextBox26.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Rebooster");
                ReboostTot = Price * newQuant;
                reboostPriceTextBox26.Text = ReboostTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void StillwaterAddButton22_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(StillwaterQuantityTextBox27.Text);

            if (newQuant > 0)
            {

                newQuant++;
                StillwaterQuantityTextBox27.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Still Water");
                StillWaterTot = Price * newQuant;
                StillwaterPriceTextBox27.Text = StillWaterTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void SparkingwaterAddButton23_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(SparkingwaterQuantityTextBox28.Text);

            if (newQuant > 0)
            {

                newQuant++;
                SparkingwaterQuantityTextBox28.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Sparkling Water");
                SparkingWaterTot = Price * newQuant;
                SparkingwaterPriceTextBox28.Text = SparkingWaterTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void SmallfriedAddButton24_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(SmallfriedQuantityTextBox29.Text);

            if (newQuant > 0)
            {

                newQuant++;
                SmallfriedQuantityTextBox29.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Small Fried Chips");
                smallFriedTot = Price * newQuant;
                SmallfriedPriceTextBox29.Text = smallFriedTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void LargeFriedAddButton25_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(LargeFriedQuantityTextBox30.Text);

            if (newQuant > 0)
            {

                newQuant++;
                LargeFriedQuantityTextBox30.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Large Fried Chips");
                LargeFriedTot = Price * newQuant;
                LargeFriedPriceTextBox30.Text = LargeFriedTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void BeefBurgerAddButton26_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BeefBurgerQuantityTextBox31.Text);

            if (newQuant > 0)
            {

                newQuant++;
                BeefBurgerQuantityTextBox31.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Beef Burger");
                BeefburgerTot = Price * newQuant;
                BeefBurgerPriceTextBox31.Text = BeefburgerTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void HotDogAddButton27_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(HotDogQuantityTextBox32.Text);

            if (newQuant > 0)
            {

                newQuant++;
                HotDogQuantityTextBox32.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Hot Dog");
                HotDogTot = Price * newQuant;
                HotDogPriceTextBox32.Text = HotDogTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }

        }


        protected void FruitSaladAddButton28_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(FruitSaladQuantityTextBox33.Text);

            if (newQuant > 0)
            {

                newQuant++;
                FruitSaladQuantityTextBox33.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Fruit salad");
                FruitSaladTot = Price * newQuant;
                FruitSaladPriceTextBox33.Text = FruitSaladTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void IcecreamCONEAddButton29_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(IcecreamCONEQuantityTextBox34.Text);

            if (newQuant > 0)
            {

                newQuant++;
                IcecreamCONEQuantityTextBox34.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Ice Cream Cone");
                IceCreamConeTot = Price * newQuant;
                IcecreamCONEPriceTextBox34.Text = IceCreamConeTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void IcecreamCUPAddButton30_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(IcecreamCUPQuantityTextBox35.Text);



            newQuant++;
            IcecreamCUPQuantityTextBox35.Text = newQuant.ToString();
            decimal Price = GetProductPrice("Ice Cream Cone (2)");
            IceCreamCupTot = Price * newQuant;
            IcecreamCUPPriceTextBox35.Text = IceCreamCupTot.ToString();
           

            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();

        }

        protected void IcecreamOreosAddButton31_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(IcecreamOreosQuantityTextBox36.Text);


            newQuant++;
            IcecreamOreosQuantityTextBox36.Text = newQuant.ToString();
            decimal Price = GetProductPrice("Ice Cream Cone(3)");
            IceCreamOreoTot = Price * newQuant;
            IcecreamOreosPriceTextBox36.Text = IceCreamOreoTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();


        }
        protected void IcecreamCUPSubButton30_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(IcecreamCUPQuantityTextBox35.Text);

            if (newQuant > 1)
            {

                newQuant--;
                IcecreamCUPQuantityTextBox35.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Ice Cream Cone (2)");
                IceCreamCupTot = Price * newQuant;
                IcecreamCUPPriceTextBox35.Text = IceCreamCupTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void IcecreamOreosSubButton31_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(IcecreamOreosQuantityTextBox36.Text);

            if (newQuant > 1)
            {

                newQuant--;
                IcecreamOreosQuantityTextBox36.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Ice Cream Cone(3)");
                IceCreamOreoTot = Price * newQuant;
                IcecreamOreosPriceTextBox36.Text = IceCreamOreoTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }


        protected void FruitSaladSubButton28_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(FruitSaladQuantityTextBox33.Text);

            if (newQuant > 1)
            {

                newQuant--;
                FruitSaladQuantityTextBox33.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Fruit salad");
                FruitSaladTot = Price * newQuant;
                FruitSaladPriceTextBox33.Text = FruitSaladTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void IcecreamCONESubButton29_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(IcecreamCONEQuantityTextBox34.Text);

            if (newQuant > 1)
            {

                newQuant--;
                IcecreamCONEQuantityTextBox34.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Ice Cream Cone");
                IceCreamConeTot = Price * newQuant;
                IcecreamCONEPriceTextBox34.Text = IceCreamConeTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }



        protected void CheeseCakeSubButton0_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(cheeseCakeQuantityTextBox5.Text);
            newQuant--;
            cheeseCakeQuantityTextBox5.Text = newQuant.ToString();

            decimal price = GetProductPrice("Cheese Cake");
            cheeseCakeTot = price * newQuant;
            cheeseCakePriceTextBox5.Text = cheeseCakeTot.ToString("0.00");

            TOTALCOST -= price;
            Total_TextBox1.Text = TOTALCOST.ToString("0.00");
        }

        protected void VelvetSubButton2_Click(object sender, EventArgs e)
        {

        }

        protected void caramelcakeSubButton5_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(CustardcaramelQuantityTextBox6.Text);
            newQuant--;
            CustardcaramelQuantityTextBox6.Text = newQuant.ToString();

            decimal price = GetProductPrice("Caramel Cake");
            CaramelcakeTot = price * newQuant;
            CaramelCakePriceTextBox10.Text = CaramelcakeTot.ToString("0.00");

            TOTALCOST -= price;
            Total_TextBox1.Text = TOTALCOST.ToString("0.00");
        }


        protected void blueberrySubButton7_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BlueberryQuantityTextBox12.Text);
            newQuant--;
            BlueberryQuantityTextBox12.Text = newQuant.ToString();

            decimal price = GetProductPrice("Blueberry Slice");
            BlueberryTot = price * newQuant;
            BlueberryPriceTextBox12.Text = BlueberryTot.ToString("0.00");

            TOTALCOST -= price;
            Total_TextBox1.Text = TOTALCOST.ToString("0.00");
        }

        protected void QueenCakeSubButton9_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(QueenCakeQuantityTextBox14.Text);

            if (newQuant > 1)
            {

                newQuant--;
                QueenCakeQuantityTextBox14.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Queen Cakes");
                QueenCaketTot = Price * newQuant;
                QueenCakePriceTextBox14.Text = QueenCaketTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void PastrypuffsSubButton10_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PastrypuffsQuantityTextBox15.Text);

            if (newQuant > 1)
            {

                newQuant--;
                PastrypuffsQuantityTextBox15.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Pastry Puffs");
                PastryPuffTot = Price * newQuant;
                PastrypuffsPriceTextBox15.Text = PastryPuffTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void CreamBunsSubButton11_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(CreamBunsQuantityTextBox16.Text);

            if (newQuant > 1)
            {

                newQuant--;
                CreamBunsQuantityTextBox16.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Cream Buns");
                CreamBunsTot = Price * newQuant;
                CreamBunsPriceTextBox16.Text = CreamBunsTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void PlainScornSubButton12_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PlainScornQuantityTextBox17.Text);

            if (newQuant > 1)
            {

                newQuant--;
                PlainScornQuantityTextBox17.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Plain Scorn");
                PlainScortTot = Price * newQuant;
                PlainScornPriceTextBox17.Text = PlainScortTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void QueenCakecheesSubButton13_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(QueenCakecheesQuantityTextBox18.Text);

            if (newQuant > 1)
            {

                newQuant--;
                QueenCakecheesQuantityTextBox18.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Queen Cakes(Cheesecake)");
                QueencakeCheeseTot = Price * newQuant;
                QueenCakecheesPriceTextBox18.Text = QueencakeCheeseTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void RaisinscornSubButton14_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(RaisinscornQuantityTextBox19.Text);

            if (newQuant > 1)
            {

                newQuant--;
                RaisinscornQuantityTextBox19.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Raisin Scorn");
                RaisinScornTot = Price * newQuant;
                RaisinscornPriceTextBox19.Text = RaisinScornTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void meltingmomentSubButton15_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(meltingmomentQuantityTextBox20.Text);

            if (newQuant > 1)
            {

                newQuant--;
                meltingmomentQuantityTextBox20.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Melting Moment Cake");
                MeltingMomentTot = Price * newQuant;
                meltingmomentPriceTextBox20.Text = MeltingMomentTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void chocolatemoseSubButton16_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(chocolatemoseQuantityTextBox21.Text);

            if (newQuant > 1)
            {

                newQuant--;
                chocolatemoseQuantityTextBox21.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Chocolate Cake");
                ChocolateMoueseTot = Price * newQuant;
                chocolatemosePriceTextBox21.Text = ChocolateMoueseTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void squarebaroneSubButton17_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(squarebaroneQuantityTextBox22.Text);

            if (newQuant > 1)
            {

                newQuant--;
                squarebaroneQuantityTextBox22.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Square Bar One Cake");
                BarOneSquareTot = Price * newQuant;
                squarebaronePriceTextBox22.Text = BarOneSquareTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void SmoothieSubButton20_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(SmoothieQuantityTextBox25.Text);

            if (newQuant > 1)
            {

                newQuant--;
                SmoothieQuantityTextBox25.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Smoothie");
                SmoothieTot = Price * newQuant;
                SmoothiePriceTextBox25.Text = SmoothieTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void reboostSubButton21_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(reboostQuantityTextBox26.Text);

            if (newQuant > 1)
            {

                newQuant--;
                reboostQuantityTextBox26.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Rebooster");
                ReboostTot = Price * newQuant;
                reboostPriceTextBox26.Text = ReboostTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void StillwaterSubButton22_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(StillwaterQuantityTextBox27.Text);

            if (newQuant > 1)
            {

                newQuant--;
                StillwaterQuantityTextBox27.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Still Water");
                StillWaterTot = Price * newQuant;
                StillwaterPriceTextBox27.Text = StillWaterTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void SparkingwaterSubButton23_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(SparkingwaterQuantityTextBox28.Text);

            if (newQuant > 1)
            {

                newQuant--;
                SparkingwaterQuantityTextBox28.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Sparkling Water");
                SparkingWaterTot = Price * newQuant;
                SparkingwaterPriceTextBox28.Text = SparkingWaterTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void SmallfriedSubButton24_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(SmallfriedQuantityTextBox29.Text);

            if (newQuant > 1)
            {

                newQuant--;
                SmallfriedQuantityTextBox29.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Small Fried Chips");
                smallFriedTot = Price * newQuant;
                SmallfriedPriceTextBox29.Text = smallFriedTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void LargeFriedSubButton25_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(LargeFriedQuantityTextBox30.Text);

            if (newQuant > 1)
            {

                newQuant--;
                LargeFriedQuantityTextBox30.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Large Fried Chips");
                LargeFriedTot = Price * newQuant;
                LargeFriedPriceTextBox30.Text = LargeFriedTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void BeefBurgerSubButton26_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BeefBurgerQuantityTextBox31.Text);

            if (newQuant > 1)
            {

                newQuant--;
                BeefBurgerQuantityTextBox31.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Beef Burger");
                BeefburgerTot = Price * newQuant;
                BeefBurgerPriceTextBox31.Text = BeefburgerTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void HotDogSubButton27_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(HotDogQuantityTextBox32.Text);

            if (newQuant > 1)
            {

                newQuant--;
                HotDogQuantityTextBox32.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Hot Dog");
                HotDogTot = Price * newQuant;
                HotDogPriceTextBox32.Text = HotDogTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void RedbullSubButton19_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(RedbullQuantityTextBox24.Text);

            if (newQuant > 1)
            {

                newQuant--;
                RedbullQuantityTextBox24.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Red Bull");
                RedbullTot = Price * newQuant;
                RedbullPriceTextBox24.Text = RedbullTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void redbull250SubButton18_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(redbull250QuantityTextBox23.Text);

            if (newQuant > 1)
            {

                newQuant--;
                redbull250QuantityTextBox23.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Red Bull 250ml");
                RedBull250Tot = Price * newQuant;
                redbull250PriceTextBox23.Text = RedBull250Tot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void frightSliceSubButton2_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(FruitSliceQuantityTextBox7.Text);
            newQuant--;
            FruitSliceQuantityTextBox7.Text = newQuant.ToString();

            decimal price = GetProductPrice("Fruit Slice");
            FruitSliceTot = price * newQuant;
            FruitSlicePriceTextBox7.Text = FruitSliceTot.ToString("0.00");

            TOTALCOST -= price;
            Total_TextBox1.Text = TOTALCOST.ToString("0.00");
        }

        protected void PastrypuffsCancelButton10_Click(object sender, EventArgs e)
        {
            PastrypuffsPanel15.Visible = false;
            PastryPuffQuant = 1;
            CancelItem("Pastry Puffs");
            PastryPuffTot = decimal.Parse(PastrypuffsPriceTextBox15.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - PastryPuffTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("pastrypuffsImageButton10Clicked");

        }

        protected void SmoothieQuantityTextBox25_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void AddApples7_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(OrangeQuantityTextBox17.Text);
            newQuant++;
            OrangeQuantityTextBox17.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Orange");
            OrangeTot = Price * newQuant;
            OrangePriceTextBox10.Text = OrangeTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void SubOrange_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(OrangeQuantityTextBox17.Text);

            if (newQuant > 1)
            {

                newQuant--;
                OrangeQuantityTextBox17.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Orange");
                OrangeTot = Price * newQuant;
                OrangePriceTextBox10.Text = OrangeTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void AddApples8_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BananaQuantityTextBox19.Text);
            newQuant++;
            BananaQuantityTextBox19.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Banana");
            BananaTot = Price * newQuant;
            BananaPriceTextBox11.Text = BananaTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void SubBAnana_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BananaQuantityTextBox19.Text);
            if (newQuant > 1)
            {

                newQuant--;
                BananaQuantityTextBox19.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Banana");
                BananaTot = Price * newQuant;
                BananaPriceTextBox11.Text = BananaTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void AddApples9_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(NartjieQuantityTextBox21.Text);
            newQuant++;
            NartjieQuantityTextBox21.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Vaartjie");
            NartjieTot = Price * newQuant;
            NartjiePriceTextBox12.Text = NartjieTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();

        }

        protected void AddApples_Click1(object sender, EventArgs e)
        {
            int newQuant = int.Parse(AppleQuantityTextBox1.Text);
            newQuant++;
            AppleQuantityTextBox1.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Apple");
            AppleTot = Price * newQuant;
            ApplePriceTextBox2.Text = AppleTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }


        protected void SubApples_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(AppleQuantityTextBox1.Text);
            if (newQuant > 1)
            {

                newQuant--;
                AppleQuantityTextBox1.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Apple");
                AppleTot = Price * newQuant;
                ApplePriceTextBox2.Text = AppleTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void SubNartjie_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(NartjieQuantityTextBox21.Text);
            if (newQuant > 1)
            {

                newQuant--;
                NartjieQuantityTextBox21.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Vaartjie");
                NartjieTot = Price * newQuant;
                NartjiePriceTextBox12.Text = NartjieTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void Menuback_Click(object sender, EventArgs e)
        {
            Response.Redirect("Menu.aspx");
        }

        protected void RoundonutAdd_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(roundDonutQuantityTextBox.Text);
            newQuant++;
            roundDonutQuantityTextBox.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Round Doughnut");
            roundDonutTot = Price * newQuant;
            RoundDonutPriceTextBox.Text = roundDonutTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }



        protected void RoundDonutSubButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(roundDonutQuantityTextBox.Text);
            if (newQuant > 1)
            {

                newQuant--;
                roundDonutQuantityTextBox.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Round Doughnut");
                roundDonutTot = Price * newQuant;
                RoundDonutPriceTextBox.Text = roundDonutTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }


        protected void RoundDonutCancel_Click(object sender, EventArgs e)
        {
            RoundDonutPanel.Visible = false;
            RoundDonutQuant = 1;
            CancelItem("Round Doughnut");
            roundDonutTot = decimal.Parse(RoundDonutPriceTextBox.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - roundDonutTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("round_donutImageButtonClicked");

        }


        protected void SnowballAddButton_Click1(object sender, EventArgs e)
        {
            {
                int newQuant = int.Parse(SnowballQuantityTextBox1.Text);
                newQuant++;
                SnowballQuantityTextBox1.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Snowball");
                decimal snowballTot = Price * newQuant;
                SnowBallPriceTextBox1.Text = snowballTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void LongDonutAddButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(LongDonutQuantityTextBox0.Text);
            newQuant++;
            LongDonutQuantityTextBox0.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Long Doughnut");
            decimal longDonutTot = Price * newQuant;
            LongDonutPriceTextBox0.Text = longDonutTot.ToString();

            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void FerreroAddButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(FerreroQuantityTextBox2.Text);
            newQuant++;
            FerreroQuantityTextBox2.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Ferrero Slice");
            decimal ferreroTot = Price * newQuant;
            FerreroPriceTextBox2.Text = ferreroTot.ToString();

            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void BlackForrestAddButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BlackForrestQuantityTextBox3.Text);
            newQuant++;
            BlackForrestQuantityTextBox3.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Black Forrest");
            decimal blackForrestTot = Price * newQuant;
            BlackForrestPriceTextBox3.Text = blackForrestTot.ToString();

            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void VelvetAddButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(VelvetQuantityTextBox4.Text);
            newQuant++;
            VelvetQuantityTextBox4.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Red Velvet");
            decimal velvetTot = Price * newQuant;
            VelvetPriceTextBox4.Text = velvetTot.ToString();

            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void SnowballSubButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(SnowballQuantityTextBox1.Text);
            if (newQuant > 1)
            {
                newQuant--;
                SnowballQuantityTextBox1.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Snowball");
                decimal snowballTot = Price * newQuant;
                SnowBallPriceTextBox1.Text = snowballTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void FerreroSubButton1_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(FerreroQuantityTextBox2.Text);
            if (newQuant > 1)
            {
                newQuant--;
                FerreroQuantityTextBox2.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Ferrero Slice");
                decimal ferreroTot = Price * newQuant;
                FerreroPriceTextBox2.Text = ferreroTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void BlackForrestSubButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BlackForrestQuantityTextBox3.Text);
            if (newQuant > 1)
            {
                newQuant--;
                BlackForrestQuantityTextBox3.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Black Forrest");
                decimal blackForrestTot = Price * newQuant;
                BlackForrestPriceTextBox3.Text = blackForrestTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void VelvetSubButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(VelvetQuantityTextBox4.Text);
            if (newQuant > 1)
            {
                newQuant--;
                VelvetQuantityTextBox4.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Red Velvet");
                decimal velvetTot = Price * newQuant;
                VelvetPriceTextBox4.Text = velvetTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void SnowBallCancelButton_Click(object sender, EventArgs e)
        {
            SnowBallPanel1.Visible = false;
            SnowballQuant = 1;
            CancelItem("SnowBall");
            decimal snowballTot = decimal.Parse(SnowBallPriceTextBox1.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - snowballTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("snowballImageButtonClicked");

        }

        protected void FerreroCancelButton_Click(object sender, EventArgs e)
        {
            FerreroPanel2.Visible = false;
            FerreroQuant = 1;
            CancelItem("Ferrero Slice");
            decimal ferreroTot = decimal.Parse(FerreroPriceTextBox2.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - ferreroTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("fereroImageButtonClicked");

        }

        protected void BlackforrestCancelButton1_Click(object sender, EventArgs e)
        {
            BlackForrestPanel3.Visible = false;
            BlackForrestQuant = 1;
            CancelItem("Black Forrest");
            decimal blackForrestTot = decimal.Parse(BlackForrestPriceTextBox3.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - blackForrestTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("blackforrestImageButtonClicked");

        }

        protected void VelvetCancelButton_Click(object sender, EventArgs e)
        {
            VelvetPanel4.Visible = false;
            VelvetQuant = 1;
            CancelItem("Velvet");
            decimal velvetTot = decimal.Parse(VelvetPriceTextBox4.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - velvetTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("velvetImageButtonClicked");

        }

        protected void LongDonutSubButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(LongDonutQuantityTextBox0.Text);
            if (newQuant > 1)
            {
                newQuant--;
                LongDonutQuantityTextBox0.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Long Doughnut");
                decimal longDonutTot = Price * newQuant;
                LongDonutPriceTextBox0.Text = longDonutTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void LOngDonutCancelButton_Click(object sender, EventArgs e)
        {
            LongDonutPanel0.Visible = false;
            RoundDonutQuant = 1;
            CancelItem("Long Doughnut");
            decimal roundDonutTot = decimal.Parse(LongDonutPriceTextBox0.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - roundDonutTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("long_donutImageButtonClicked");

        }

        protected void AddBheeseCakeutton0_Click(object sender, EventArgs e)
        {

            int newQuant = int.Parse(cheeseCakeQuantityTextBox5.Text);
            newQuant++;
            cheeseCakeQuantityTextBox5.Text = newQuant.ToString();

            decimal price = GetProductPrice("Cheese Cake");
            cheeseCakeTot = price * newQuant;
            cheeseCakePriceTextBox5.Text = cheeseCakeTot.ToString("0.00");

            TOTALCOST += price;
            Total_TextBox1.Text = TOTALCOST.ToString("0.00");
        }

        protected void CustardcaramelSubButton1_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(CustardcaramelQuantityTextBox6.Text);

            if (newQuant > 1)
            {
                newQuant--;
                CustardcaramelQuantityTextBox6.Text = newQuant.ToString();

                decimal price = GetProductPrice("Custard Caramel");
                CustardCaramelTot = price * newQuant;
                CustardcaramelPriceTextBox6.Text = CustardCaramelTot.ToString("0.00");

                TOTALCOST -= price;
                Total_TextBox1.Text = TOTALCOST.ToString("0.00");
            }
        }

        protected void CustardcaramelCancelButton1_Click(object sender, EventArgs e)
        {

            CustardcaramelPanel6.Visible = false;
            CustardcaramelQuant = 1;
            CancelItem("Custard Caramel Cake");
            decimal CustardCaramelTot = decimal.Parse(CustardcaramelPriceTextBox6.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - CustardCaramelTot;
            Total_TextBox1.Text = TOTALCOST.ToString("0.00");
            Session.Remove("CustardCaramelImageButton1Clicked");

        }

        protected void fruitsliceAddButton2_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(FruitSliceQuantityTextBox7.Text);
            newQuant++;
            FruitSliceQuantityTextBox7.Text = newQuant.ToString();

            decimal price = GetProductPrice("Fruit Slice");
            FruitSliceTot = price * newQuant;
            FruitSlicePriceTextBox7.Text = FruitSliceTot.ToString("0.00");

            TOTALCOST += price;
            Total_TextBox1.Text = TOTALCOST.ToString("0.00");
        }

        protected void HotcrossbunSubButton3_Click(object sender, EventArgs e)
        {

            int newQuant = int.Parse(HotcrossbunQuantityTextBox8.Text);

            if (newQuant > 1)
            {
                newQuant--;
                HotcrossbunQuantityTextBox8.Text = newQuant.ToString();

                decimal price = GetProductPrice("Hot Cross Bun");
                HotCrossBunTot = price * newQuant;
                HotcrossbunPriceTextBox8.Text = HotCrossBunTot.ToString("0.00");

                TOTALCOST -= price;
                Total_TextBox1.Text = TOTALCOST.ToString("0.00");
            }
        }

        protected void HotcrossbunCancelButton3_Click(object sender, EventArgs e)
        {

            HotcrossbunPanel8.Visible = false;
            hotcrossbunQuant = 1;
            CancelItem("Hot Cross Buns");
            decimal HotCrossBunTot = decimal.Parse(HotcrossbunPriceTextBox8.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - HotCrossBunTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("hotcrossbunsImageButton3Clicked");

        }

        protected void CupcakeAddButton4_Click(object sender, EventArgs e)
        {

            int newQuant = int.Parse(CupcakeQuantityTextBox9.Text);
            newQuant++;
            CupcakeQuantityTextBox9.Text = newQuant.ToString();

            decimal price = GetProductPrice("Cup Cakes");
            CupCakeTot = price * newQuant;
            CupcakePriceTextBox9.Text = CupCakeTot.ToString("0.00");

            TOTALCOST += price;
            Total_TextBox1.Text = TOTALCOST.ToString("0.00");
        }

        protected void CupcakeSubButton4_Click(object sender, EventArgs e)
        {


            int newQuant = int.Parse(CupcakeQuantityTextBox9.Text);

            if (newQuant > 1)
            {
                newQuant--;
                CupcakeQuantityTextBox9.Text = newQuant.ToString();

                decimal price = GetProductPrice("Cup Cakes");
                CupCakeTot = price * newQuant;
                CupcakePriceTextBox9.Text = CupCakeTot.ToString("0.00");

                TOTALCOST -= price;
                Total_TextBox1.Text = TOTALCOST.ToString("0.00");
            }
        }

        protected void CupcakeCancelButton4_Click(object sender, EventArgs e)
        {


            CupcakePanel9.Visible = false;
            cupcakeQuant = 1;
            CancelItem("Cup Cakes");
            decimal CupCakeTot = decimal.Parse(CupcakePriceTextBox9.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - CupCakeTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("CupcakesImageButton4Clicked");

        }

        protected void caramelcakeAddButton5_Click(object sender, EventArgs e)
        {


            int newQuant = int.Parse(CustardcaramelQuantityTextBox6.Text);
            newQuant++;
            CustardcaramelQuantityTextBox6.Text = newQuant.ToString();

            decimal price = GetProductPrice("Caramel Cake");
            CaramelcakeTot = price * newQuant;
            CaramelCakePriceTextBox10.Text = CaramelcakeTot.ToString("0.00");

            TOTALCOST += price;
            Total_TextBox1.Text = TOTALCOST.ToString("0.00");
        }

        protected void SwizrollSubButton6_Click(object sender, EventArgs e)
        {


            int newQuant = int.Parse(SwizrollQuantityTextBox11.Text);

            if (newQuant > 1)
            {
                newQuant--;
                SwizrollQuantityTextBox11.Text = newQuant.ToString();

                decimal price = GetProductPrice("Swiss Roll");
                SwizzRollTot = price * newQuant;
                SwizzRollPriceTextBox11.Text = SwizzRollTot.ToString("0.00");

                TOTALCOST -= price;
                Total_TextBox1.Text = TOTALCOST.ToString("0.00");
            }
        }

        protected void SwizrollCancelButton6_Click(object sender, EventArgs e)
        {


            SwizrollPanel11.Visible = false;
            swissrollquant = 1;
            CancelItem("Swiss Roll");
            decimal SwissRollTot = decimal.Parse(SwizzRollPriceTextBox11.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - SwissRollTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("SwisRoleImageButton5Clicked");
        }

        protected void blueberryAddButton7_Click(object sender, EventArgs e)
        {


            int newQuant = int.Parse(BlueberryQuantityTextBox12.Text);
            newQuant++;
            BlueberryQuantityTextBox12.Text = newQuant.ToString();

            decimal price = GetProductPrice("Blueberry Slice");
            BlueberryTot = price * newQuant;
            BlueberryPriceTextBox12.Text = BlueberryTot.ToString("0.00");

            TOTALCOST += price;
            Total_TextBox1.Text = TOTALCOST.ToString("0.00");
        }

        protected void BarOneSubButton8_Click(object sender, EventArgs e)
        {


            int newQuant = int.Parse(BarOneQuantityTextBox13.Text);

            if (newQuant > 1)
            {
                newQuant--;
                BarOneQuantityTextBox13.Text = newQuant.ToString();

                decimal price = GetProductPrice("Bar One Cake");
                BarOnesliceTot = price * newQuant;
                BarOnePriceTextBox13.Text = BarOnesliceTot.ToString("0.00");

                TOTALCOST -= price;
                Total_TextBox1.Text = TOTALCOST.ToString("0.00");
            }
        }

        protected void BarOneCancelButton8_Click(object sender, EventArgs e)
        {


            BarOnePanel.Visible = false;
            BarOneSquareQuant = 1;
            CancelItem("Bar One Cake");
            decimal BarOneTot = decimal.Parse(BarOnePriceTextBox13.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - BarOneTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("barOneImageButton7Clicked");

        }
        protected void cheeseCakeCancelButton0_Click(object sender, EventArgs e)
        {
            cheeseCakepanel5.Visible = false;
            cheeseCakeQuant = 1;
            CancelItem("CheeseCake");
            cheeseCakeTot = decimal.Parse(cheeseCakePriceTextBox5.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - cheeseCakeTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("CheeseCakeImageButton0Clicked");

        }
        protected void FruitSliceCancelButton2_Click(object sender, EventArgs e)
        {
            FruitSlicePanel7.Visible = false;
            FruitSliceQuant = 1;
            CancelItem("Fruit Slice");
            FruitSliceTot = decimal.Parse(FruitSlicePriceTextBox7.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - FruitSliceTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("fruit_sliceImageButton2Clicked");

        }
        protected void caramelcakeCancelButton5_Click(object sender, EventArgs e)
        {
            caramelcakePanel10.Visible = false;
            caramelcakeQuant = 1;
            CancelItem("Caramel Cake");
            CaramelcakeTot = decimal.Parse(CaramelCakePriceTextBox10.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - CaramelcakeTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("caramelImageButton5Clicked");

        }
        protected void blueberryCancelButton7_Click(object sender, EventArgs e)
        {
            blueberryPanel12.Visible = false;
            BlueberryQuant = 1;
            CancelItem("Blueberry Slice");
            BlueberryTot = decimal.Parse(BlueberryPriceTextBox12.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - BlueberryTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("blueberryImageButton6Clicked");

        }
        protected void QueenCakeCancelButton9_Click(object sender, EventArgs e)
        {
            QueenCakePanel14.Visible = false;
            QueenCakeQuant = 1;
            CancelItem("Queen Cakes");
            QueenCaketTot = decimal.Parse(QueenCakePriceTextBox14.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - QueenCaketTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("QueencakesImageButton9Clicked");
        }
        protected void PlainScornCancelButton12_Click(object sender, EventArgs e)
        {
            PlainScornPanel17.Visible = false;
            PlainScornQuant = 1;
            CancelItem("Plain Scorn");
            PlainScortTot = decimal.Parse(PlainScornPriceTextBox17.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - PlainScortTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("PlainScornImageButton6Clicked");

        }

        protected void QueenCakecheesCancelButton13_Click(object sender, EventArgs e)
        {
            QueenCakecheesePanel18.Visible = false;
            QueencakeCheeseQuant = 1;
            CancelItem("Queen Cakes(Cheesecake)");
            QueencakeCheeseTot = decimal.Parse(QueenCakecheesPriceTextBox18.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - QueencakeCheeseTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("queenCakesCheeseImageButton7Clicked");

        }

        protected void RaisinscornCancelButton14_Click(object sender, EventArgs e)
        {
            RaisinscornPanel19.Visible = false;
            RaisinScornQuant = 1;
            CancelItem("Raisin Scorn");
            RaisinScornTot = decimal.Parse(RaisinscornPriceTextBox19.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - RaisinScornTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("RaisinScornImageButton8Clicked");

        }

        protected void meltingmomentCancelButton15_Click(object sender, EventArgs e)
        {
            meltingmomentPanel20.Visible = false;
            MeltingMomentQuant = 1;
            CancelItem("Melting Moment Cake");
            MeltingMomentTot = decimal.Parse(meltingmomentPriceTextBox20.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - MeltingMomentTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("Melting_momentImageButton9Clicked");

        }

        protected void chocolatemoseCancelButton16_Click(object sender, EventArgs e)
        {
            chocolatecatePanel21.Visible = false;
            ChocolateMoueseQuant = 1;
            CancelItem("Chocolate Cake");
            ChocolateMoueseTot = decimal.Parse(chocolatemosePriceTextBox21.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - ChocolateMoueseTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("Chocolate_MouesImageButton10Clicked");
        }

        protected void squarebaroneCancelButton17_Click(object sender, EventArgs e)
        {
            squarebaronePanel22.Visible = false;
            BarOneSquareQuant = 1;
            CancelItem("Square Bar One Cake");
            BarOneSquareTot = decimal.Parse(squarebaronePriceTextBox22.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - BarOneSquareTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("barOne_squareSliceImageButton11Clicked");

        }

        protected void redbull250CancelButton18_Click(object sender, EventArgs e)
        {
            redbull250Panel23.Visible = false;
            RedBull250Quant = 1;
            CancelItem("Red Bull 250ml");
            RedBull250Tot = decimal.Parse(redbull250PriceTextBox23.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - RedBull250Tot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("RedBull250ImageButton5Clicked");

        }

        protected void RedbullCancelButton19_Click(object sender, EventArgs e)
        {
            RedbullPanel24.Visible = false;
            RedbullQuant = 1;
            CancelItem("Red Bull ");
            RedbullTot = decimal.Parse(RedbullPriceTextBox24.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - RedbullTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("RedBullSmallsImageButton6Clicked");

        }

        protected void SmoothieCancelButton20_Click(object sender, EventArgs e)
        {
            SmoothiePanel25.Visible = false;
            SmoothieQuant = 1;
            CancelItem("Smoothie");
            SmoothieTot = decimal.Parse(SmoothiePriceTextBox25.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - SmoothieTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("SmoothieImageButton7Clicked");

        }

        protected void reboostCancelButton21_Click(object sender, EventArgs e)
        {
            reboostPanel26.Visible = false;
            ReboostQuant = 1;
            CancelItem("Rebooster");
            ReboostTot = decimal.Parse(reboostPriceTextBox26.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - ReboostTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("ReboostImageButton8Clicked");

        }

        protected void StillwaterCancelButton22_Click(object sender, EventArgs e)
        {
            StillwaterPanel27.Visible = false;
            StillWaterQuant = 1;
            CancelItem("Still Water");
            StillWaterTot = decimal.Parse(StillwaterPriceTextBox27.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - StillWaterTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("StillWaterImageButton9Clicked");

        }

        protected void SparkingwaterCancelButton23_Click(object sender, EventArgs e)
        {
            SparkingwaterPanel28.Visible = false;
            SparkingWaterQuant = 1;
            CancelItem("Sparkling Water");
            SparkingWaterTot = decimal.Parse(SparkingwaterPriceTextBox28.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - SparkingWaterTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("SparklingWaterImageButton10Clicked");

        }

        protected void SmallfriedCancelButton24_Click(object sender, EventArgs e)
        {
            SmallfriedPanel29.Visible = false;
            SmallFriedQuant = 1;
            CancelItem("Small Fried Chips");
            smallFriedTot = decimal.Parse(SmallfriedPriceTextBox29.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - smallFriedTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("SmallFriedImageButton5Clicked");

        }

        protected void LargeFriedCancelButton25_Click(object sender, EventArgs e)
        {
            LargeFriedPanel30.Visible = false;
            LargeFriedQuant = 1;
            CancelItem("Large Fried Chips");
            LargeFriedTot = decimal.Parse(LargeFriedPriceTextBox30.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - LargeFriedTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("LargeFriedsImageButton6Clicked");

        }

        protected void BeefBurgerCancelButton26_Click(object sender, EventArgs e)
        {
            BeefBurgerPanel31.Visible = false;
            BeefburgerQuant = 1;
            CancelItem("Beef Burger");
            BeefburgerTot = decimal.Parse(BeefBurgerPriceTextBox31.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - BeefburgerTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("BurgerImageButton7Clicked");

        }

        protected void HotDogCancelButton27_Click(object sender, EventArgs e)
        {
            HotDogPanel32.Visible = false;
            CancelItem("Hot Dog");
            HotDogQuant = 1;
            HotDogTot = decimal.Parse(HotDogPriceTextBox32.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - HotDogTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("HotdogsImageButton8Clicked");

        }

        protected void FruitSaladCancelButton28_Click(object sender, EventArgs e)
        {
            FruitSaladPanel33.Visible = false;
            CancelItem("Fruit Salad");
            FruitSaladQuant = 1;
            FruitSaladTot = decimal.Parse(FruitSaladPriceTextBox33.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - FruitSaladTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("FruitSaladImageButton9Clicked");

        }

        protected void IcecreamCONECancelButton29_Click(object sender, EventArgs e)
        {
            IcecreamCONEPanel34.Visible = false;
            CancelItem("Ice Cream Cone");
            IceCreamConeQuant = 1;
            IceCreamConeTot = decimal.Parse(IcecreamCONEPriceTextBox34.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - IceCreamConeTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("IcecreamConeImageButton8Clicked");

        }

        protected void IcecreamCUPCancelButton30_Click(object sender, EventArgs e)
        {
            IcecreamCUPPanel35.Visible = false;
            CancelItem("Ice Cream Cone (2)");
            IceCreamCupQuant = 1;
            IceCreamCupTot = decimal.Parse(IcecreamCUPPriceTextBox35.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - IceCreamCupTot;
            Total_TextBox1.Text = TOTALCOST.ToString("0.00");
            Session.Remove("CupIcecreamImageButton9Clicked");

        }

        protected void IcecreamOreosCancelButton31_Click(object sender, EventArgs e)
        {

            IcecreamOreosPanel36.Visible = false;
            CancelItem("Ice Cream Cone(3)");
            IceCreamOreoQuant = 1;
            IceCreamOreoTot = decimal.Parse(IcecreamOreosPriceTextBox36.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - IceCreamOreoTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("OreoicecreamImageButton10Clicked");

        }

        protected void CreamBunsCancelButton11_Click(object sender, EventArgs e)
        {
            CreamBunsPanel16.Visible = false;
            CancelItem("Cream Buns");
            CreamBunsQuant = 1;
            CreamBunsTot = decimal.Parse(CreamBunsPriceTextBox16.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - CreamBunsTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
            Session.Remove("cream_bunImageButton5Clicked");

        }

    }
}