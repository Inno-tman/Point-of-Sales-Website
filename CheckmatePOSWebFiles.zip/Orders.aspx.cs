﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CheckMWebs
{
    public partial class Orders : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Context.User.Identity.IsAuthenticated)
            {
                Email.Visible = false;
                ID.Visible = false;
                Email.Text = Context.User.Identity.Name;
            }

            using (SqlConnection connection = new SqlConnection("Data Source=146.230.177.46;Initial Catalog=GroupWst9;User ID=GroupWst9;Password=87fnn"))
            {
                connection.Open();
                string checkQuery = "SELECT Name, Customer_ID FROM CMW_Customer WHERE Email = @Email";
                SqlCommand checkCommand = new SqlCommand(checkQuery, connection);
                checkCommand.Parameters.AddWithValue("@Email", Email.Text);

                // Execute the query and read the result
                SqlDataReader reader = checkCommand.ExecuteReader();

                if (reader.Read())
                {
                    //string employeeName = reader["Name"].ToString();
                    string customerID = reader["Customer_ID"].ToString();
                   // NameTextBox2.Text = employeeName; // Set the value in NameTextBox2
                    ID.Text = customerID; // Set the value in IDTextBox2
                }

                reader.Close();
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}