﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CheckMWebs.Startup))]
namespace CheckMWebs
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
