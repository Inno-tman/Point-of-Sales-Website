﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CheckMWebs
{

    public partial class Menu : System.Web.UI.Page
    {

        private HashSet<string> clickedButtons = new HashSet<string>();
        List<string> selectedItems;

        protected int num
        {
            get { return (int)(ViewState["num"] ?? 0); }
            set { ViewState["num"] = value; }
        }

        protected decimal Total;
        protected decimal price;
        protected int AppleQuant;

        private void CalculateAndDisplayRowCount()
        {
            using (SqlConnection connection = new SqlConnection("Data Source=146.230.177.46;Initial Catalog=GroupWst9;User ID=GroupWst9;Password=87fnn"))
            {
                connection.Open();

                string countQuery = "SELECT COUNT(*) FROM Items";
                SqlCommand countCommand = new SqlCommand(countQuery, connection);
                int rowCount = (int)countCommand.ExecuteScalar();

                // Assuming you have a TextBox named "RowCountTextBox" on your page to display the count
                numberOfItemsTXTbox.Text = rowCount.ToString();
            }
        }
        private bool DoesItemExist(string itemName)
        {
            using (SqlConnection connection = new SqlConnection("Data Source=146.230.177.46;Initial Catalog=GroupWst9;User ID=GroupWst9;Password=87fnn"))
            {
                connection.Open();
                string checkQuery = "SELECT COUNT(*) FROM Items WHERE selectedItems = @ItemName";
                SqlCommand checkCommand = new SqlCommand(checkQuery, connection);
                checkCommand.Parameters.AddWithValue("@ItemName", itemName);
                int itemCount = (int)checkCommand.ExecuteScalar();

                return itemCount > 0;
            }
        }
        private void UpdateButtonAndLabel(string itemName, ImageButton button, Label label)
        {
            if (DoesItemExist(itemName))
            {
                button.Style["filter"] = "brightness(40%)";
                label.Visible = true;
            }
            else
            {
                button.Style["filter"] = "brightness(100%)";
                label.Visible = false;
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CalculateAndDisplayRowCount();

                UpdateButtonAndLabel("Banana", BananaBUtton, bananaLabel);
                UpdateButtonAndLabel("Peach", PlumButton1, peachLabel);
                UpdateButtonAndLabel("Orange", OrangeButton, OrangeLabel1);
                UpdateButtonAndLabel("Apple", AppleButton, AppleLabel);
                UpdateButtonAndLabel("Nartjie", NartjieButton, NartjieLabel);
                UpdateButtonAndLabel("Grapes", GrapesButton1, GrapesLabel1);
                UpdateButtonAndLabel("Round Doughnut", round_donutImageButton, rounddonutLabel1);
                UpdateButtonAndLabel("Long Doughnut", long_donutImageButton, longDonutLabel1);
                UpdateButtonAndLabel("Snowball", snowballImageButton, SnowbalLabel1);
                UpdateButtonAndLabel("Black Forrest", blackforrestImageButton, BlackforrestLabel1);
                UpdateButtonAndLabel("Velvet", velvetImageButton, VelvetLabel1);
                UpdateButtonAndLabel("Ferrero Slice", fereroImageButton, ferreroLabel1);
                UpdateButtonAndLabel("CheeseCake", CheeseCakeImageButton0, cheesecakeLabel1);
                UpdateButtonAndLabel("Custard Caramel Cake", CustardCaramelImageButton1, custardLabel1);
                UpdateButtonAndLabel("Fruit Slice", fruit_sliceImageButton2, fruitsliceLabel1);
                UpdateButtonAndLabel("Hot Cross Buns", hotcrossbunsImageButton3, hotcrossbunLabel1);
                UpdateButtonAndLabel("Cup Cakes", CupcakesImageButton4, CupCakeLabel1);
                UpdateButtonAndLabel("Caramel Cake", caramelImageButton5, CaramelLabel1);
                UpdateButtonAndLabel("Swiss Roll", SwisRoleImageButton5, SwisrollLabel1);
                UpdateButtonAndLabel("Blueberry Slice", blueberryImageButton6, blueberryLabel1);
                UpdateButtonAndLabel("Bar One Cake", barOneImageButton7, barOneLabel1);
                UpdateButtonAndLabel("Queen Cakes", QueencakesImageButton9, QueenCakesLabel1);
                UpdateButtonAndLabel("Pastry Puffs", pastrypuffsImageButton10, pastryLabel);
                UpdateButtonAndLabel("Cream Buns", cream_bunImageButton5, CreamBunLabel1);
                UpdateButtonAndLabel("Plain Scorn", PlainScornImageButton6, PlainScornLabel1);
                UpdateButtonAndLabel("Queen Cakes(Cheesecake)", queenCakesCheeseImageButton7, queencakecheeseLabel1);
                UpdateButtonAndLabel("Raisin Scorn", RaisinScornImageButton8, RaisinScornLabel1);
                UpdateButtonAndLabel("Melting Moment Cake", Melting_momentImageButton9, MeltingmomentLabel1);
                UpdateButtonAndLabel("Chocolate Cake", Chocolate_MouesImageButton10, ChocolateLabel1);
                UpdateButtonAndLabel("Square Bar One Cake", barOne_squareSliceImageButton11, barOneSqrLabel1);
                UpdateButtonAndLabel("Small Fried Chips", smallFriedImageButton5, smallFriedLabel1);
                UpdateButtonAndLabel("Large Fried Chips", LargeFriedsImageButton6, largeFriedsLabel1);
                UpdateButtonAndLabel("Beef Burger", BurgerImageButton7, BurgerLabel1);
                UpdateButtonAndLabel("Hot Dog", hotdogsImageButton8, hotdogsLabel1);
                UpdateButtonAndLabel("Fruit Salad", fruitsaladImageButton9, fruitsaladLabel1);
                UpdateButtonAndLabel("Red Bull 250ml", RedBull250ImageButton5, RedBull250Label1);
                UpdateButtonAndLabel("Red Bull", redbullsmallsImageButton6, redbullSmallLabel1);
                UpdateButtonAndLabel("Smoothie", SmoothieImageButton7, SmoothieLabel1);
                UpdateButtonAndLabel("Rebooster", reboostImageButton8, reboostLabel1);
                UpdateButtonAndLabel("Still Water", stillwaterImageButton9, stillwaterLabel1);
                UpdateButtonAndLabel("Sparkling Water", Sparkling_waterImageButton10, sparklingWaterLabel1);
                UpdateButtonAndLabel("Ice Cream Cone", IcecreamConeImageButton8, IcecreamConeLabel1);
                UpdateButtonAndLabel("Ice Cream Cone (2)", cupicecreamImageButton9, cupicecreamLabel1);
                UpdateButtonAndLabel("Ice Cream Cone(3)", oreoicecreamImageButton10, oreoicecreamLabel1);
                



            }

        }


        private void ToggleItem(string itemName)
        {
            using (SqlConnection connection = new SqlConnection("Data Source=146.230.177.46;Initial Catalog=GroupWst9;User ID=GroupWst9;Password=87fnn"))
            {
                connection.Open();
                string checkQuery = "SELECT COUNT(*) FROM Items WHERE selectedItems = @ItemName";
                SqlCommand checkCommand = new SqlCommand(checkQuery, connection);
                checkCommand.Parameters.AddWithValue("@ItemName", itemName);
                int itemCount = (int)checkCommand.ExecuteScalar();

                if (itemCount == 0)
                {
                    // Item is not in the database, so insert it
                    string insertQuery = "INSERT INTO Items (selectedItems) VALUES (@ItemName)";
                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);
                    insertCommand.Parameters.AddWithValue("@ItemName", itemName);
                    insertCommand.ExecuteNonQuery();
                }
                else
                {
                    // Item is in the database, so delete it
                    string deleteQuery = "DELETE FROM Items WHERE selectedItems = @ItemName";
                    SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection);
                    deleteCommand.Parameters.AddWithValue("@ItemName", itemName);
                    deleteCommand.ExecuteNonQuery();
                }

            }
        }

        protected void AppleButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["AppleButtonClicked"] == null)
            {
                Session["AppleButtonClicked"] = true;
            }

            ToggleItem("Apple");
            Session["AppleButtonClicked"] = false;
            Response.Redirect("Menu.aspx");// Reset the button state
        }



        protected void NartjieButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["NartjieButtonClicked"] == null)
            {

                Session["NartjieButtonClicked"] = true;
            }

            ToggleItem("Nartjie");
            Session["NartjieButtonClicked"] = false;
            Response.Redirect("Menu.aspx");

        }

    

        protected void ButtonNartjie_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["ButtonNartjieClicked"] == null)
            {

                Session["ButtonNartjieClicked"] = true;


            }
            ToggleItem("Banana");
            Session["ButtonNartjieClicked"] = false;
            Response.Redirect("Menu.aspx");


        }

        protected void PlumButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["PlumButton1Clicked"] == null)
            {

                Session["PlumButton1Clicked"] = true;



            }
            ToggleItem("Peach");
            Session["PlumButton1Clicked"] = false;
            Response.Redirect("Menu.aspx");


        }

        protected void GrapesButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["GrapesButton1Clicked"] == null)
            {

                Session["GrapesButton1Clicked"] = true;
            }
            ToggleItem("Grapes");
            Session["GrapesButton1Clicked"] = false;
            Response.Redirect("Menu.aspx");





        }



        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["ImageButton4Clicked"] == null)
            {
                Session["ImageButton4Clicked"] = true;
            }
            ToggleItem("Orange");
            Session["ImageButton4Clicked"] = false; ;
            Response.Redirect("Menu.aspx");




        }
        protected void cartButton_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Cart.aspx");
        }

        protected void round_donutImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["round_donutImageButtonClicked"] == null)
            {
                Session["round_donutImageButtonClicked"] = true;
            }
            ToggleItem("Round Doughnut");
            Session["round_donutImageButtonClicked"] = false;
            Response.Redirect("Menu.aspx");



        }

        protected void long_donutImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["long_donutImageButtonClicked"] == null)
            {
                Session["long_donutImageButtonClicked"] = true;
            }
            ToggleItem("Long Doughnut");
            Session["long_donutImageButtonClicked"] = false;
            Response.Redirect("Menu.aspx");



        }

        protected void snowballImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["snowballImageButtonClicked"] == null)
            {
                Session["snowballImageButtonClicked"] = true;
            }
            ToggleItem("Snowball");
            Session["snowballImageButtonClicked"] = false;
            Response.Redirect("Menu.aspx");



        }

        protected void blackforrestImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["blackforrestImageButtonClicked"] == null)
            {
                Session["blackforrestImageButtonClicked"] = true;
            }
            ToggleItem("Black Forrest");
            Session["blackforrestImageButtonClicked"] = false;
            Response.Redirect("Menu.aspx");



        }

        protected void velvetImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["velvetImageButtonClicked"] == null)
            {
                Session["velvetImageButtonClicked"] = true;
            }
            ToggleItem("Velvet");
            Session["velvetImageButtonClicked"] = false;
            Response.Redirect("Menu.aspx");



        }

        protected void fereroImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["fereroImageButtonClicked"] == null)
            {
                Session["fereroImageButtonClicked"] = true;
            }
            ToggleItem("Ferrero Slice");
            Session["fereroImageButtonClicked"] = false;
            Response.Redirect("Menu.aspx");

        }

        protected void CheeseCakeImageButton0_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["CheeseCakeImageButton0Clicked"] == null)
            {
                Session["CheeseCakeImageButton0Clicked"] = true;
            }
            ToggleItem("CheeseCake");

            Session["CheeseCakeImageButton0Clicked"] = false;
            Response.Redirect("Menu.aspx");

        }

        protected void CustardCaramelImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["CustardCaramelImageButton1Clicked"] == null)
            {
                Session["CustardCaramelImageButton1Clicked"] = true;
            }
            ToggleItem("Custard Caramel Cake");
            Session["CustardCaramelImageButton1Clicked"] = false;
            Response.Redirect("Menu.aspx");

        }

        protected void fruit_sliceImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["fruit_sliceImageButton2Clicked"] == null)
            {
                Session["fruit_sliceImageButton2Clicked"] = true;
            }
            ToggleItem("Fruit Slice");
            Session["fruit_sliceImageButton2Clicked"] = false;
            Response.Redirect("Menu.aspx");

        }

        protected void hotcrossbunsImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["hotcrossbunsImageButton3Clicked"] == null)
            {
                Session["hotcrossbunsImageButton3Clicked"] = true;
            }
            ToggleItem("Hot Cross Buns");
            Session["hotcrossbunsImageButton3Clicked"] = false;
            Response.Redirect("Menu.aspx");


        }

        protected void CupcakesImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["CupcakesImageButton4Clicked"] == null)
            {
                Session["CupcakesImageButton4Clicked"] = true;
            }
            Session["CupcakesImageButton4Clicked"] = false;

            ToggleItem("Cup Cakes");
            Response.Redirect("Menu.aspx");


        }

        protected void caramelImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["caramelImageButton5Clicked"] == null)
            {
                Session["caramelImageButton5Clicked"] = true;
            }
            ToggleItem("Caramel Cake");
            Session["caramelImageButton5Clicked"] = false;
            Response.Redirect("Menu.aspx");



        }

        protected void SwisRoleImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["SwisRoleImageButton5Clicked"] == null)
            {
                Session["SwisRoleImageButton5Clicked"] = true;
            }
            ToggleItem("Swiss Roll");
            Session["SwisRoleImageButton5Clicked"] = false;
            Response.Redirect("Menu.aspx");


        }

        protected void blueberryImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["blueberryImageButton6Clicked"] == null)
            {
                Session["blueberryImageButton6Clicked"] = true;
            }
            ToggleItem("Blueberry Slice");
            Session["blueberryImageButton6Clicked"] = false;
            Response.Redirect("Menu.aspx");

        }

        protected void barOneImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["barOneImageButton7Clicked"] == null)
            {
                Session["barOneImageButton7Clicked"] = true;
            }
            ToggleItem("Bar One Cake");
            Session["barOneImageButton7Clicked"] = false;
            Response.Redirect("Menu.aspx");


        }
        //unfinished
        protected void QueencakesImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["QueencakesImageButton9Clicked"] == null)
            {
                Session["QueencakesImageButton9Clicked"] = true;
            }
            ToggleItem("Queen Cakes");
            Session["QueencakesImageButton9Clicked"] = false;
            Response.Redirect("Menu.aspx");


        }

        protected void pastrypuffsImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["pastrypuffsImageButton10Clicked"] == null)
            {
                Session["pastrypuffsImageButton10Clicked"] = true;
            }
            ToggleItem("Pastry Puffs");
            Session["pastrypuffsImageButton10Clicked"] = false;
            Response.Redirect("Menu.aspx");

        }

        protected void cream_bunImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["cream_bunImageButton5Clicked"] == null)
            {
                Session["cream_bunImageButton5Clicked"] = true;
            }
            ToggleItem("Cream Buns");
            Session["cream_bunImageButton5Clicked"] = false;
            Response.Redirect("Menu.aspx");

        }

        protected void PlainScornImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["PlainScornImageButton6Clicked"] == null)
            {
                Session["PlainScornImageButton6Clicked"] = true;
            }
            ToggleItem("Plain Scorn");
            Session["PlainScornImageButton6Clicked"] = false;
            Response.Redirect("Menu.aspx");


        }

        protected void queenCakesCheeseImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["queenCakesCheeseImageButton7Clicked"] == null)
            {
                Session["queenCakesCheeseImageButton7Clicked"] = true;
            }
            Session["queenCakesCheeseImageButton7Clicked"] = false;
            ToggleItem("Queen Cakes(Cheesecake)");
            Response.Redirect("Menu.aspx");

        }

        protected void RaisinScornImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["RaisinScornImageButton8Clicked"] == null)
            {
                Session["RaisinScornImageButton8Clicked"] = true;
            }
            Session["RaisinScornImageButton8Clicked"] = false;
            ToggleItem("Raisin Scorn");
            Response.Redirect("Menu.aspx");

        }

        protected void Melting_momentImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["Melting_momentImageButton9Clicked"] == null)
            {
                Session["Melting_momentImageButton9Clicked"] = false;
            }
            Session["Melting_momentImageButton9Clicked"] = false;
            ToggleItem("Melting Moment Cake");
            Response.Redirect("Menu.aspx");

        }

        protected void Chocolate_MouesImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["Chocolate_MouesImageButton10Clicked"] == null)
            {
                Session["Chocolate_MouesImageButton10Clicked"] = true;
            }
            Session["Chocolate_MouesImageButton10Clicked"] = false;
            ToggleItem("Chocolate Cake");
            Response.Redirect("Menu.aspx");

        }

        protected void barOne_squareSliceImageButton11_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["barOne_squareSliceImageButton11Clicked"] == null)
            {
                Session["barOne_squareSliceImageButton11Clicked"] = true;
            }
            Session["barOne_squareSliceImageButton11Clicked"] = false;
            ToggleItem("Square Bar One Cake");
            Response.Redirect("Menu.aspx");

        }

        protected void smallFriedImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["SmallFriedImageButton5Clicked"] == null)
            {
                Session["SmallFriedImageButton5Clicked"] = true;
            }
            Session["SmallFriedImageButton5Clicked"] = false;
            ToggleItem("Small Fried Chips");
            Response.Redirect("Menu.aspx");

        }

        protected void LargeFriedsImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["LargeFriedsImageButton6Clicked"] == null)
            {
                Session["LargeFriedsImageButton6Clicked"] = true;
            }
            Session["LargeFriedsImageButton6Clicked"] = false;
            ToggleItem("Large Fried Chips");
            Response.Redirect("Menu.aspx");

        }

        protected void BurgerImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["BurgerImageButton7Clicked"] == null)
            {
                Session["BurgerImageButton7Clicked"] = true;
            }
            Session["BurgerImageButton7Clicked"] = false;
            ToggleItem("Beef Burger");
            Response.Redirect("Menu.aspx");

        }

        protected void hotdogsImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["HotdogsImageButton8Clicked"] == null)
            {
                Session["HotdogsImageButton8Clicked"] = true;
            }
            Session["HotdogsImageButton8Clicked"] = false;
            ToggleItem("Hot Dog");
            Response.Redirect("Menu.aspx");

        }

        protected void fruitsaladImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["FruitSaladImageButton9Clicked"] == null)
            {
                Session["FruitSaladImageButton9Clicked"] = true;
            }
            Session["FruitSaladImageButton9Clicked"] = false;
            ToggleItem("Fruit Salad");
            Response.Redirect("Menu.aspx");

        }

        protected void RedBull250ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["RedBull250ImageButton5Clicked"] == null)
            {
                Session["RedBull250ImageButton5Clicked"] = true;
            }
            Session["RedBull250ImageButton5Clicked"] = false;
            ToggleItem("Red Bull 250ml");
            Response.Redirect("Menu.aspx");

        }

        protected void redbullsmallsImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["RedBullSmallsImageButton6Clicked"] == null)
            {
                Session["RedBullSmallsImageButton6Clicked"] = true;
            }
            Session["RedBullSmallsImageButton6Clicked"] = false;
            ToggleItem("Red Bull");
            Response.Redirect("Menu.aspx");

        }

        protected void SmoothieImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["SmoothieImageButton7Clicked"] == null)
            {
                Session["SmoothieImageButton7Clicked"] = true;
            }
            Session["SmoothieImageButton7Clicked"] = false;
            ToggleItem("Smoothie");
            Response.Redirect("Menu.aspx");

        }

        protected void reboostImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["ReboostImageButton8Clicked"] == null)
            {
                Session["ReboostImageButton8Clicked"] = true;
            }
            Session["ReboostImageButton8Clicked"] = false;
            ToggleItem("Rebooster");
            Response.Redirect("Menu.aspx");

        }

        protected void stillwaterImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["StillWaterImageButton9Clicked"] == null)
            {
                Session["StillWaterImageButton9Clicked"] = true;
            }
            Session["StillWaterImageButton9Clicked"] = false;
            ToggleItem("Still Water");
            Response.Redirect("Menu.aspx");

        }

        protected void Sparkling_waterImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["SparklingWaterImageButton10Clicked"] == null)
            {
                Session["SparklingWaterImageButton10Clicked"] = true;
            }
            Session["SparklingWaterImageButton10Clicked"] = false;
            ToggleItem("Sparkling Water");
            Response.Redirect("Menu.aspx");

        }

        protected void IcecreamConeImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["IcecreamConeImageButton8Clicked"] == null)
            {
                Session["IcecreamConeImageButton8Clicked"] = true;
            }
            Session["IcecreamConeImageButton8Clicked"] = false;
            ToggleItem("Ice Cream Cone");
            Response.Redirect("Menu.aspx");

        }

        protected void cupicecreamImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["CupIcecreamImageButton9Clicked"] == null)
            {
                Session["CupIcecreamImageButton9Clicked"] = true;
            }
            Session["CupIcecreamImageButton9Clicked"] = false;
            ToggleItem("Ice Cream Cone (2)");
            Response.Redirect("Menu.aspx");

        }

        protected void oreoicecreamImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["OreoicecreamImageButton10Clicked"] == null)
            {
                Session["OreoicecreamImageButton10Clicked"] = true;
            }
            Session["OreoicecreamImageButton10Clicked"] = false;
            ToggleItem("Ice Cream Cone(3)");
            Response.Redirect("Menu.aspx");

        }

        protected void FruitsButton1_Click(object sender, ImageClickEventArgs e)
        {
            FruitsPanel1.Visible = true;

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            dessertsPanel2.Visible = true;

        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            Fast_Foods.Visible = true;

        }

        protected void ImageButton4_Click1(object sender, ImageClickEventArgs e)
        {
            Bearings_Panel3.Visible = true;

        }

        protected void BakeryButton5_Click(object sender, ImageClickEventArgs e)
        {
            BakeryPanel.Visible = true;
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void RegisterButton3_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }

        protected void numberOfItemsTXTbox_TextChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
