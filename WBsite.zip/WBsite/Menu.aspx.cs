﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBsite
{

    public partial class Menu : System.Web.UI.Page
    {

        private HashSet<string> clickedButtons = new HashSet<string>();

        protected int num
        {
            get { return (int)(ViewState["num"] ?? 0); }
            set { ViewState["num"] = value; }
        }

        protected decimal Total;
        protected decimal price;
        protected int AppleQuant;

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void IncrementNum()
        {
            num++;
            numberOfItemsTXTbox.Text = num.ToString();

        }
        private void ToggleItem(string itemName)
        {
            if (Session[itemName + "Clicked"] == null)
            {
                IncrementNum();
                Session[itemName + "Clicked"] = true;

                if (Session["SelectedItems"] == null)
                {
                    Session["SelectedItems"] = new List<string>();
                }

                List<string> selectedItems = (List<string>)Session["SelectedItems"];
                selectedItems.Add(itemName);
            }

            // Response.Redirect("Cart.aspx");
        }

        protected void AppleButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["AppleButtonClicked"] == null)
            {
                Session["AppleButtonClicked"] = true;
                ToggleItem("Apple");

            }



        }

        protected void NartjieButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["NartjieButtonClicked"] == null)
            {

                Session["NartjieButtonClicked"] = true;
                ToggleItem("Nartjie");


            }

        }

        protected void ButtonNartjie_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["ButtonNartjieClicked"] == null)
            {

                Session["ButtonNartjieClicked"] = true;
                ToggleItem("Banana");


            }

        }

        protected void PlumButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["PlumButton1Clicked"] == null)
            {

                Session["PlumButton1Clicked"] = true;
                ToggleItem("Plum");


            }

        }

        protected void GrapesButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["GrapesButton1Clicked"] == null)
            {

                Session["GrapesButton1Clicked"] = true;
                ToggleItem("Grape");


            }

        }



        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["ImageButton4Clicked"] == null)
            {
                Session["ImageButton4Clicked"] = true;
                ToggleItem("Orange");

            }

        }
        protected void cartButton_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Cart.aspx");
        }

        protected void round_donutImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["round_donutImageButtonClicked"] == null)
            {
                Session["round_donutImageButtonClicked"] = true;
                ToggleItem("Round Donut");

            }
        }

        protected void long_donutImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["long_donutImageButtonClicked"] == null)
            {
                Session["long_donutImageButtonClicked"] = true;
                ToggleItem("Long Donut");

            }
        }

        protected void snowballImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["snowballImageButtonClicked"] == null)
            {
                Session["snowballImageButtonClicked"] = true;
                ToggleItem("Snow Ball");

            }
        }

        protected void blackforrestImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["blackforrestImageButtonClicked"] == null)
            {
                Session["blackforrestImageButtonClicked"] = true;
                ToggleItem("Black Forrest");

            }
        }

        protected void velvetImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["velvetImageButtonClicked"] == null)
            {
                Session["velvetImageButtonClicked"] = true;
                ToggleItem("Velvet");

            }
        }

        protected void fereroImageButton_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["fereroImageButtonClicked"] == null)
            {
                Session["fereroImageButtonClicked"] = true;
                ToggleItem("Ferrero");

            }
        }

        protected void CheeseCakeImageButton0_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["CheeseCakeImageButton0Clicked"] == null)
            {
                Session["CheeseCakeImageButton0Clicked"] = true;
                ToggleItem("Cheese Cake");

            }
        }

        protected void CustardCaramelImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["CustardCaramelImageButton1Clicked"] == null)
            {
                Session["CustardCaramelImageButton1Clicked"] = true;
                ToggleItem("Custard Caramel");

            }
        }

        protected void fruit_sliceImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["fruit_sliceImageButton2Clicked"] == null)
            {
                Session["fruit_sliceImageButton2Clicked"] = true;
                ToggleItem("fruit Slice");

            }
        }

        protected void hotcrossbunsImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["hotcrossbunsImageButton3Clicked"] == null)
            {
                Session["hotcrossbunsImageButton3Clicked"] = true;
                ToggleItem("Hot Cross Bun");

            }
        }

        protected void CupcakesImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["CupcakesImageButton4Clicked"] == null)
            {
                Session["CupcakesImageButton4Clicked"] = true;
                ToggleItem("Cup Cake");

            }
        }

        protected void caramelImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["caramelImageButton5Clicked"] == null)
            {
                Session["caramelImageButton5Clicked"] = true;
                ToggleItem("Caramel ");

            }
        }

        protected void SwisRoleImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["SwisRoleImageButton5Clicked"] == null)
            {
                Session["SwisRoleImageButton5Clicked"] = true;
                ToggleItem("Swiss Roll");
            }
        }

        protected void blueberryImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["blueberryImageButton6Clicked"] == null)
            {
                Session["blueberryImageButton6Clicked"] = true;
                ToggleItem("Blueberry");
            }
        }

        protected void barOneImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["barOneImageButton7Clicked"] == null)
            {
                Session["barOneImageButton7Clicked"] = true;
                ToggleItem("BarOne");
            }
        }

        protected void QueencakesImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["QueencakesImageButton9Clicked"] == null)
            {
                Session["QueencakesImageButton9Clicked"] = true;
                ToggleItem("Queencakes");
            }
        }

        protected void pastrypuffsImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["pastrypuffsImageButton10Clicked"] == null)
            {
                Session["pastrypuffsImageButton10Clicked"] = true;
                ToggleItem("Pastry puffs");
            }
        }

        protected void cream_bunImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["cream_bunImageButton5Clicked"] == null)
            {
                Session["cream_bunImageButton5Clicked"] = true;
                ToggleItem("Cream Bun");
            }
        }

        protected void PlainScornImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["PlainScornImageButton6Clicked"] == null)
            {
                Session["PlainScornImageButton6Clicked"] = true;
                ToggleItem("PlainScorn");
            }
        }

        protected void queenCakesCheeseImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["queenCakesCheeseImageButton7Clicked"] == null)
            {
                Session["queenCakesCheeseImageButton7Clicked"] = true;
                ToggleItem("queenCakesCheese");
            }
        }

        protected void RaisinScornImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["RaisinScornImageButton8Clicked"] == null)
            {
                Session["RaisinScornImageButton8Clicked"] = true;
                ToggleItem("RaisinScorn");
            }
        }

        protected void Melting_momentImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["Melting_momentImageButton9Clicked"] == null)
            {
                Session["Melting_momentImageButton9Clicked"] = true;
                ToggleItem("Melting moment");
            }
        }

        protected void Chocolate_MouesImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["Chocolate_MouesImageButton10Clicked"] == null)
            {
                Session["Chocolate_MouesImageButton10Clicked"] = true;
                ToggleItem("Chocolate Moues");
            }
        }

        protected void barOne_squareSliceImageButton11_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["barOne_squareSliceImageButton11Clicked"] == null)
            {
                Session["barOne_squareSliceImageButton11Clicked"] = true;
                ToggleItem("barOne_squareSlice");
            }
        }
    }
}
