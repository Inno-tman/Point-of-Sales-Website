﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI;

namespace WBsite
{

    public partial class Login : Page
    {
        public string Name { get; private set; }
        public string Surname { get; private set; }
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        protected void login_button_Click(object sender, EventArgs e)
        {
            string enteredUsername = Username.Text.Trim();
            string enteredPassword = Password.Text;

            // Connect to the database
            string connectionString = WebConfigurationManager.ConnectionStrings["GroupWst9ConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Check if the email and password combination exists in the CustomerWeb table
                string customerQuery = "SELECT COUNT(*) FROM CustomerWeb WHERE Email = @Email AND Password = @Password";
                using (SqlCommand customerCommand = new SqlCommand(customerQuery, connection))
                {
                    customerCommand.Parameters.AddWithValue("@Email", enteredUsername);
                    customerCommand.Parameters.AddWithValue("@Password", enteredPassword);

                    int customerCount = (int)customerCommand.ExecuteScalar();

                    if (customerCount == 1)
                    {
                        // Customer authentication successful; redirect to a welcome page or perform other actions
                        Response.Redirect("Menu.aspx");
                        return; // Return to prevent further processing
                    }
       
                }
                string employeeQuery = "SELECT  [Surname] ,[Name], [Employee_ID] FROM [Employee] WHERE [Email] = @Email AND [Employee_Type] = @type  " ;
                using (SqlCommand employeeCommand = new SqlCommand(employeeQuery, connection))
                {
                    employeeCommand.Parameters.AddWithValue("@Email", enteredUsername);
                    employeeCommand.Parameters.AddWithValue("@type", "Cashier");



                    SqlDataReader reader = employeeCommand.ExecuteReader();

                    if (reader.Read())
                    {
                        string employeeName = reader["Name"].ToString();
                        int employeeID = Convert.ToInt32(reader["Employee_ID"]);

                        // Generate the expected password for the employee
                        string expectedPassword = employeeName + employeeID;
                        
                        if (enteredPassword == expectedPassword )
                        {
                            // Employee authentication successful; redirect to the Employee page or perform other actions
                            Name = employeeName;
                            Surname = reader["Surname"].ToString();
                            Employee em = new Employee();
                            em.Ename = Name;
                            em.Esurname = Surname;
                            Response.Redirect("Employee.aspx");




                        }
                        else
                        {
                            // Invalid password for the employee
                            Password.BorderColor = System.Drawing.Color.Red;
                        }
                    }
                    else
                    {
                        // User with the entered email not found in either CustomerWeb or Employee table
                        Response.Write("User not found.");
                    }

                    reader.Close();
                }
                if(Username.Text == "Manager" && Password.Text == "1234")
                {
                    Response.Redirect("Manager.aspx");
                }


                // If not a customer, check if the email exists in the Employee table

            }
        }
    }
}
