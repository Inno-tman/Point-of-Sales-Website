﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBsite
{
    public partial class Employee : System.Web.UI.Page
    {
        public string Ename{ get; set; }
        public string Esurname{ get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
           // Login L = new Login();
            //Ename = L.Name;
            //Esurname = L.Surname;
            string log = "You Logged in As: " + Ename + " " + Esurname ;
            log_AS.Text = log;

        }

        
    }
}