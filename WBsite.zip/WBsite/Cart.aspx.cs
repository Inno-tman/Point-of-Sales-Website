﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Configuration;

namespace WBsite
{
    public partial class Cart : System.Web.UI.Page
    {
        public int GrapeQuant =1;
        public int BananaQuant =1;
        public int NartjieQuant =1;
        public int OrangeQuant =1;
        public int AppleQuant = 1;
        public int PlumQuant = 1;
        public int FerreroQuant = 1;
        public int SnowballQuant = 1;
        public int BlackForrestQuant = 1;
        public int VelvetQuant = 1;
        public int LOngDonutQuant = 1;
        public int RoundDonutQuant = 1;


        public decimal Appleprice;
        public decimal Orangeprice;
        public decimal Bananaprice;
        public decimal Nartjieprice;
        public decimal Peachprice;
        public decimal grapeprice;
        public decimal ferreroprice;
        public decimal snowballprice;
        public decimal velvetprice;
        public decimal blackforrestprice;
        public decimal rounddonutprice;
        public decimal longdonutprice;


        public decimal AppleTot;
        public decimal NartjieTot;
        public decimal GrapeTot;
        public decimal PeachTot;
        public decimal BananaTot;
        public decimal OrangeTot;
        public decimal FerreroTot;
        public decimal LongDonutTot;
        public decimal roundDonutTot;
        public decimal SnowballTot;
        public decimal blackForrestTot;
        public decimal VelvetTot;


        public decimal TOTALCOST;





        private List<string> selectedItems = new List<string>(); // Declare the list at the class level

        private decimal GetProductPrice(string productDescription)
        {
            decimal price = 0;
            string connectionString = ConfigurationManager.ConnectionStrings["GroupWst9ConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT [Price] FROM [Product] WHERE [Description] = @Description";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Description", productDescription);
                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        decimal.TryParse(result.ToString(), out price);
                    }
                }
            }

            return price;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Retrieve the selected items from session
                selectedItems = Session["SelectedItems"] as List<string>;
                TOTALCOST = AppleTot + NartjieTot + GrapeTot + PeachTot + BananaTot + OrangeTot;
                Total_TextBox1.Text=TOTALCOST.ToString();
                // Show/hide the panels based on selected items
                if (selectedItems != null)
                {
                    foreach (string selectedItem in selectedItems)
                    {
                        switch (selectedItem)
                        {
                            case "Apple":
                                ApplePanel.Visible = true;
                                AppleQuantityTextBox1.Text = AppleQuant.ToString();

                                Appleprice = GetProductPrice("Apple");
                                ApplePriceTextBox2.Text = Appleprice.ToString("0.00");

                                // Calculate the total cost for Apples and add it to TOTALCOST
                                AppleTot = Appleprice * AppleQuant;
                                TOTALCOST += AppleTot;
                                break;

                            case "Nartjie":
                                NartjiePanel.Visible = true;
                                NartjieQuantityTextBox21.Text = NartjieQuant.ToString();

                                Nartjieprice = GetProductPrice("Vaartjie");
                                NartjiePriceTextBox12.Text = Nartjieprice.ToString("0.00");

                                // Calculate the total cost for Nartjies and add it to TOTALCOST
                                NartjieTot = Nartjieprice * NartjieQuant;
                                TOTALCOST += NartjieTot;
                                break;

                            case "Banana":
                                BananaPanel.Visible = true;
                                BananaQuantityTextBox19.Text = BananaQuant.ToString();

                                Bananaprice = GetProductPrice("Banana");
                                BananaPriceTextBox11.Text = Bananaprice.ToString("0.00");

                                BananaTot = Bananaprice * BananaQuant;
                                TOTALCOST += BananaTot;
                                break;
                            case "Plum":
                                PlumPanel.Visible = true;
                                PeachQuantityTextBox15.Text = PlumQuant.ToString();

                                Peachprice = GetProductPrice("Peach");
                                PeachPriceTextBox9.Text = Peachprice.ToString("0.00");

                                PeachTot = Peachprice * PlumQuant;
                                TOTALCOST += PeachTot;
                                break;
                            case "Grape":
                                PearPanel.Visible = true;
                                PearQuantityTextBox13.Text = GrapeQuant.ToString();

                                grapeprice = GetProductPrice("Grapes");
                                PearPriceTextBox8.Text = grapeprice.ToString("0.00");

                                GrapeTot = grapeprice * GrapeQuant;
                                TOTALCOST += GrapeTot;
                                break;
                            case "Orange":
                                OrangePanel.Visible = true;
                                OrangeQuantityTextBox17.Text = OrangeQuant.ToString();

                                Orangeprice = GetProductPrice("Orange");
                                OrangePriceTextBox10.Text = Orangeprice.ToString("0.00");

                                OrangeTot = Orangeprice * OrangeQuant;
                                TOTALCOST += OrangeTot;
                                break;

                            case "Round Donut":
                               RoundDonutPanel.Visible = true;
                               roundDonutQuantityTextBox.Text =RoundDonutQuant.ToString();

                                rounddonutprice = GetProductPrice("Round Doughnut");
                               RoundDonutPriceTextBox.Text = rounddonutprice.ToString("0.00");

                               roundDonutTot  = rounddonutprice * RoundDonutQuant;
                                TOTALCOST += roundDonutTot;
                                break;

                            case "Long Donut":
                                LongDonutPanel0.Visible = true;
                                LongDonutQuantityTextBox0.Text = LOngDonutQuant.ToString();

                                longdonutprice = GetProductPrice("Long Doughnut");
                                LongDonutPriceTextBox0.Text = longdonutprice.ToString("0.00");

                                LongDonutTot = longdonutprice * LOngDonutQuant;
                                TOTALCOST += LongDonutTot;
                                break;

                            case "Snow Ball":
                                SnowBallPanel1.Visible = true;
                                SnowballQuantityTextBox1.Text = SnowballQuant.ToString();

                                snowballprice = GetProductPrice("Snowball");
                                SnowBallPriceTextBox1.Text = snowballprice.ToString("0.00");

                                SnowballTot = snowballprice * SnowballQuant;
                                TOTALCOST += SnowballTot;
                                break;

                            case "Ferrero":
                                FerreroPanel2.Visible = true;
                                FerreroQuantityTextBox2.Text = FerreroQuant.ToString();

                                ferreroprice = GetProductPrice("Ferrero Slice");
                                FerreroPriceTextBox2.Text = ferreroprice.ToString("0.00");

                                FerreroTot = ferreroprice * FerreroQuant;
                                TOTALCOST += FerreroTot;
                                break;

                            case "Black Forrest":
                                BlackForrestPanel3.Visible = true;
                                BlackForrestQuantityTextBox3.Text = BlackForrestQuant.ToString();

                                blackforrestprice = GetProductPrice("Black Forrest");
                                BlackForrestPriceTextBox3.Text = blackforrestprice.ToString("0.00");

                                blackForrestTot = blackforrestprice * BlackForrestQuant;
                                TOTALCOST += blackForrestTot;
                                break;

                            case "Velvet":
                                VelvetPanel4.Visible = true;
                                VelvetQuantityTextBox4.Text = VelvetQuant.ToString();

                                velvetprice = GetProductPrice("Red Velvet");
                                VelvetPriceTextBox4.Text = velvetprice.ToString("0.00");

                                VelvetTot = velvetprice * VelvetQuant;
                                TOTALCOST += VelvetTot;
                                break;


                                // Add cases for other items as needed
                        }
                    }
                }
                Total_TextBox1.Text = TOTALCOST.ToString();

            }

        }



        protected void AddApples_Click(object sender, EventArgs e)
        {

        }

        protected void COnfirm_Click(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void cancelApple_Click(object sender, EventArgs e)
        {
            ApplePanel.Visible = false;
            AppleQuant = 0;

            AppleTot = decimal.Parse(ApplePriceTextBox2.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - AppleTot;
            Total_TextBox1.Text = TOTALCOST.ToString();


        }

        protected void cancelPear_Click(object sender, EventArgs e)
        {
            PearPanel.Visible = false;
            GrapeQuant = 1;

            GrapeTot = decimal.Parse(PearPriceTextBox8.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - GrapeTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void cancelPeach_Click(object sender, EventArgs e)
        {
            PlumPanel.Visible = false;
            PlumQuant = 1;

            PeachTot = decimal.Parse(PeachPriceTextBox9.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - PeachTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
        

        }

        protected void cancelOrange_Click(object sender, EventArgs e)
        {
            OrangePanel.Visible = false;
            OrangeQuant = 1;

            OrangeTot = decimal.Parse(OrangePriceTextBox10.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - OrangeTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void cancelBanana_Click(object sender, EventArgs e)
        {
            BananaPanel.Visible = false;
            BananaQuant = 1;

            BananaTot = decimal.Parse(BananaPriceTextBox11.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - BananaTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void cancelNartjie_Click(object sender, EventArgs e)
        {
            NartjiePanel.Visible = false;
            NartjieQuant = 1;

            NartjieTot = decimal.Parse(NartjiePriceTextBox12.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - NartjieTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void AddApples5_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PearQuantityTextBox13.Text);
            newQuant++;
            PearQuantityTextBox13.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Grapes");
            GrapeTot = Price * newQuant;
            PearPriceTextBox8.Text = GrapeTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();


        }

        protected void SubPear_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PearQuantityTextBox13.Text);
            if (newQuant > 1)
            {
                newQuant--;
                PearQuantityTextBox13.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Grapes");
                GrapeTot = Price * newQuant;
                PearPriceTextBox8.Text = GrapeTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void AddApples6_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PeachQuantityTextBox15.Text);
            newQuant++;
            PeachQuantityTextBox15.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Peach");
            PeachTot = Price * newQuant;
            PeachPriceTextBox9.Text = PeachTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void SubPeach_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(PeachQuantityTextBox15.Text);

            if (newQuant > 1)
            {

                newQuant--;
                PeachQuantityTextBox15.Text = newQuant.ToString();
                decimal Price = GetProductPrice("Peach");
                PeachTot = Price * newQuant;
                PeachPriceTextBox9.Text = PeachTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void AddApples7_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(OrangeQuantityTextBox17.Text);
            newQuant++;
            OrangeQuantityTextBox17.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Orange");
            OrangeTot = Price * newQuant;
            OrangePriceTextBox10.Text = OrangeTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void SubOrange_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(OrangeQuantityTextBox17.Text);

            if (newQuant > 1)
            {

                newQuant--;
                OrangeQuantityTextBox17.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Orange");
                OrangeTot = Price * newQuant;
                OrangePriceTextBox10.Text = OrangeTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void AddApples8_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BananaQuantityTextBox19.Text);
            newQuant++;
            BananaQuantityTextBox19.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Banana");
            BananaTot = Price * newQuant;
            BananaPriceTextBox11.Text = BananaTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void SubBAnana_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BananaQuantityTextBox19.Text);
            if (newQuant > 1)
            {

                newQuant--;
                BananaQuantityTextBox19.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Banana");
                BananaTot = Price * newQuant;
                BananaPriceTextBox11.Text = BananaTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void AddApples9_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(NartjieQuantityTextBox21.Text);
            newQuant++;
            NartjieQuantityTextBox21.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Vaartjie");
            NartjieTot = Price * newQuant;
            NartjiePriceTextBox12.Text = NartjieTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();

        }

        protected void AddApples_Click1(object sender, EventArgs e)
        {
            int newQuant = int.Parse(AppleQuantityTextBox1.Text);
            newQuant++;
            AppleQuantityTextBox1.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Apple");
            AppleTot = Price * newQuant;
            ApplePriceTextBox2.Text = AppleTot.ToString();


            TOTALCOST =decimal.Parse(Total_TextBox1.Text)+ Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }


        protected void SubApples_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(AppleQuantityTextBox1.Text);
            if (newQuant > 1)
            {

                newQuant--;
                AppleQuantityTextBox1.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Apple");
                AppleTot = Price * newQuant;
                ApplePriceTextBox2.Text = AppleTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void SubNartjie_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(NartjieQuantityTextBox21.Text);
            if (newQuant > 1)
            {

                newQuant--;
                NartjieQuantityTextBox21.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Vaartjie");
                NartjieTot = Price * newQuant;
                NartjiePriceTextBox12.Text = NartjieTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void Menuback_Click(object sender, EventArgs e)
        {
            Response.Redirect("Menu.aspx");
        }

        protected void RoundonutAdd_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(roundDonutQuantityTextBox.Text);
            newQuant++;
            roundDonutQuantityTextBox.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Round Doughnut");
            roundDonutTot  = Price * newQuant;
            RoundDonutPriceTextBox.Text =roundDonutTot.ToString();


            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }



        protected void RoundDonutSubButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(roundDonutQuantityTextBox.Text);
            if (newQuant > 1)
            {

                newQuant--;
                roundDonutQuantityTextBox.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Round Doughnut");
                roundDonutTot = Price * newQuant;
                RoundDonutPriceTextBox.Text = roundDonutTot.ToString();


                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }


        protected void RoundDonutCancel_Click(object sender, EventArgs e)
        {
           RoundDonutPanel .Visible = false;
           RoundDonutQuant = 1;

            roundDonutTot = decimal.Parse(RoundDonutPriceTextBox.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - roundDonutTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }


        protected void SnowballAddButton_Click1(object sender, EventArgs e)
        {
            {
                int newQuant = int.Parse(SnowballQuantityTextBox1.Text);
                newQuant++;
                SnowballQuantityTextBox1.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Snowball");
                decimal snowballTot = Price * newQuant;
                SnowBallPriceTextBox1.Text = snowballTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void LongDonutAddButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(LongDonutQuantityTextBox0.Text);
            newQuant++;
            LongDonutQuantityTextBox0.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Long Doughnut");
            decimal longDonutTot = Price * newQuant;
            LongDonutPriceTextBox0.Text = longDonutTot.ToString();

            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void FerreroAddButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(FerreroQuantityTextBox2.Text);
            newQuant++;
            FerreroQuantityTextBox2.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Ferrero Slice");
            decimal ferreroTot = Price * newQuant;
            FerreroPriceTextBox2.Text = ferreroTot.ToString();

            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void BlackForrestAddButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BlackForrestQuantityTextBox3.Text);
            newQuant++;
            BlackForrestQuantityTextBox3.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Black Forrest");
            decimal blackForrestTot = Price * newQuant;
            BlackForrestPriceTextBox3.Text = blackForrestTot.ToString();

            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void VelvetAddButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(VelvetQuantityTextBox4.Text);
            newQuant++;
            VelvetQuantityTextBox4.Text = newQuant.ToString();

            decimal Price = GetProductPrice("Red Velvet");
            decimal velvetTot = Price * newQuant;
            VelvetPriceTextBox4.Text = velvetTot.ToString();

            TOTALCOST = decimal.Parse(Total_TextBox1.Text) + Price;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void SnowballSubButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(SnowballQuantityTextBox1.Text);
            if (newQuant > 1)
            {
                newQuant--;
                SnowballQuantityTextBox1.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Snowball");
                decimal snowballTot = Price * newQuant;
                SnowBallPriceTextBox1.Text = snowballTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void FerreroSubButton1_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(FerreroQuantityTextBox2.Text);
            if (newQuant > 1)
            {
                newQuant--;
                FerreroQuantityTextBox2.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Ferrero Slice");
                decimal ferreroTot = Price * newQuant;
                FerreroPriceTextBox2.Text = ferreroTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void BlackForrestSubButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(BlackForrestQuantityTextBox3.Text);
            if (newQuant > 1)
            {
                newQuant--;
                BlackForrestQuantityTextBox3.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Black Forrest");
                decimal blackForrestTot = Price * newQuant;
                BlackForrestPriceTextBox3.Text = blackForrestTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void VelvetSubButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(VelvetQuantityTextBox4.Text);
            if (newQuant > 1)
            {
                newQuant--;
                VelvetQuantityTextBox4.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Red Velvet");
                decimal velvetTot = Price * newQuant;
                VelvetPriceTextBox4.Text = velvetTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void SnowBallCancelButton_Click(object sender, EventArgs e)
        {
            SnowBallPanel1.Visible = false;
            SnowballQuant = 1;

            decimal snowballTot = decimal.Parse(SnowBallPriceTextBox1.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - snowballTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void FerreroCancelButton_Click(object sender, EventArgs e)
        {
            FerreroPanel2.Visible = false;
            FerreroQuant = 1;

            decimal ferreroTot = decimal.Parse(FerreroPriceTextBox2.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - ferreroTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void BlackforrestCancelButton1_Click(object sender, EventArgs e)
        {
            BlackForrestPanel3.Visible = false;
            BlackForrestQuant = 1;

            decimal blackForrestTot = decimal.Parse(BlackForrestPriceTextBox3.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - blackForrestTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void VelvetCancelButton_Click(object sender, EventArgs e)
        {
            VelvetPanel4.Visible = false;
            VelvetQuant = 1;

            decimal velvetTot = decimal.Parse(VelvetPriceTextBox4.Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - velvetTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }

        protected void LongDonutSubButton_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(LongDonutQuantityTextBox0.Text);
            if (newQuant > 1)
            {
                newQuant--;
                LongDonutQuantityTextBox0.Text = newQuant.ToString();

                decimal Price = GetProductPrice("Long Doughnut");
                decimal longDonutTot = Price * newQuant;
                LongDonutPriceTextBox0.Text = longDonutTot.ToString();

                TOTALCOST = decimal.Parse(Total_TextBox1.Text) - Price;
                Total_TextBox1.Text = TOTALCOST.ToString();
            }
        }

        protected void LOngDonutCancelButton_Click(object sender, EventArgs e)
        {
           LongDonutPanel0 .Visible = false;
            RoundDonutQuant= 1;

            decimal roundDonutTot = decimal.Parse(LongDonutPriceTextBox0 .Text);
            TOTALCOST = decimal.Parse(Total_TextBox1.Text) - roundDonutTot;
            Total_TextBox1.Text = TOTALCOST.ToString();
        }
    }
}