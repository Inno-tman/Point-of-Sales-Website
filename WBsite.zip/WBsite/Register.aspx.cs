﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Net.Mail;
using System.Net;




namespace WBsite
{



    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Initialize ModelErrorMessage here
                ModelErrorMessage.Text = ""; // Set an initial empty message
            }
        }

        protected void registerButton_Click(object sender, EventArgs e)
        {
            if (!IsValidEmail(EmailTextBox.Text))
            {
                ModelErrorMessage.Text = "Invalid email address format. Please enter a valid email address.";
                return; // Exit the registration process
            }
            if (passwordTextBox.Text != ConfirmpassTextBox.Text)
            {
                ModelErrorMessage.Text = "Passwords do not match"; // Use .Text instead of .Equals
            }
            else
            {
                string connectionString = ConfigurationManager.ConnectionStrings["GroupWst9ConnectionString"].ConnectionString;

                // Create a new SqlConnection
                using (SqlConnection connection = new SqlConnection(connectionString))
                {

                    // Check if the email already exists in the database
                    string checkEmailQuery = "SELECT COUNT(*) FROM CustomerWeb WHERE Email = @Email";

                    using (SqlCommand checkEmailCmd = new SqlCommand(checkEmailQuery, connection))
                    {
                        // Set the email parameter value
                        checkEmailCmd.Parameters.AddWithValue("@Email", EmailTextBox.Text);

                        connection.Open();

                        int emailCount = (int)checkEmailCmd.ExecuteScalar();

                        // Check if an account with the same email already exists
                        if (emailCount > 0)
                        {
                            // Email address already exists
                            ModelErrorMessage.Text = "An account with this email address already exists.";
                        }
                        else
                        {

                            string query = "INSERT INTO CustomerWeb (Name, Surname, Email, Password) VALUES (@Name, @Surname, @Email, @Password)";

                            // Create a new SqlCommand with the query and connection
                            using (SqlCommand cmd = new SqlCommand(query, connection))
                            {
                                // Set the parameter values from the TextBoxes
                                cmd.Parameters.AddWithValue("@Name", NameTextBox.Text);
                                cmd.Parameters.AddWithValue("@Surname", SurnameTextBox.Text);
                                cmd.Parameters.AddWithValue("@Email", EmailTextBox.Text);
                                cmd.Parameters.AddWithValue("@Password", passwordTextBox.Text);

                                // Open the connection

                                // Execute the SQL query (insert)
                                int rowsAffected = cmd.ExecuteNonQuery();

                                // Check if the insert was successful
                                if (rowsAffected > 0)
                                {
                                    // Registration successful
                                    ModelErrorMessage.Text = "Registration successful!";
                                    ClearTextBoxes();
                                    SendRegistrationConfirmationEmail(EmailTextBox.Text);
                                    Response.Redirect("Login.aspx");

                                }
                                else
                                {
                                    // Registration failed
                                    ModelErrorMessage.Text = "Registration failed. Please try again.";
                                }
                            }
                        }
                    }
                }

                

            }
        }
        private void ClearTextBoxes()
        {
            NameTextBox.Text = "";
            SurnameTextBox.Text = "";
            EmailTextBox.Text = "";
            passwordTextBox.Text = "";
            ConfirmpassTextBox.Text = "";
        }
        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email && addr.Address.Contains(".");
            }
            catch
            {
                return false;
            }
        }


        private void SendRegistrationConfirmationEmail(string userEmail)
        {
            try
            {
                // Configure your SMTP settings (you can also place these in Web.config)
                string smtpServer = "smtp.gmail.com";
                int smtpPort = 587; // Use the appropriate port
                string smtpUsername = "Checkmatecafegroup@gmail.com";
                string smtpPassword = "@Checkmate23";

                using (SmtpClient smtpClient = new SmtpClient(smtpServer, smtpPort))
                {
                    smtpClient.EnableSsl = true; // Enable SSL if required
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.Credentials = new NetworkCredential(smtpUsername, smtpPassword);

                    // Create the email message
                    MailMessage mailMessage = new MailMessage();
                    mailMessage.From = new MailAddress("Checkmatecafegroup@gmail.com"); // Replace with your sender email
                    mailMessage.To.Add(userEmail); // User's registered email address
                    mailMessage.Subject = "Registration Confirmation";
                    mailMessage.Body = "Thank you for registering on our Checkmate's CAFE. Your registration was successful. \n your Login Details are as follow: \n userName: "+EmailTextBox.Text+"\n Password: "+passwordTextBox.Text;

                    // Send the email
                    smtpClient.Send(mailMessage);
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions related to email sending
                // You can log the exception or display an error message
                ModelErrorMessage.Text = "Registration successful, but email confirmation failed: " + ex.Message;
            }
        }
    }


}
