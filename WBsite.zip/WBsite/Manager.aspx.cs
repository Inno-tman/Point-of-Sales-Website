﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBsite
{
    public partial class Manager : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void StockImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            // Hide all GridViews
            SalesGridView3.Visible = false;
            CustomerGridView4.Visible = false;
            EmployeeDAtagridView.Visible = false;
            StockGridView5.Visible = true;
           
            CustomerLabel.Visible = false;
            Sales.Visible = false;
            StockLabel.Visible = true;
            EmployeeLanel.Visible = false;

            EmployeeSearchLabel.Visible = false;
            searchEmployee.Visible = false;
            CustomerSearchLabel.Visible = false;
            CustomerSearch_TextBox1.Visible = false;
            stockSearch_TextBox1.Visible = true;
            stockSearchLabel.Visible = true;
            fromDateTextBox1.Visible = false;
            TODATE.Visible = false;
            ToDate_TextBox2.Visible = false;
            FromaDateLabel.Visible = false;
            Button1.Visible = false;
        }

        protected void EmployeeImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            // Hide all GridViews
            SalesGridView3.Visible = false;
            CustomerGridView4.Visible = false;
            EmployeeDAtagridView.Visible = true;
            StockGridView5.Visible = false;
           
            CustomerLabel.Visible = false;
            Sales.Visible = false;
            StockLabel.Visible = false;
            EmployeeLanel.Visible = true;

            EmployeeSearchLabel.Visible = true;
            searchEmployee.Visible = true;
            CustomerSearchLabel.Visible = false;
            CustomerSearch_TextBox1.Visible = false;
            stockSearch_TextBox1.Visible = false;
            stockSearchLabel.Visible = false;
            fromDateTextBox1.Visible = false;
            TODATE.Visible = false;
            ToDate_TextBox2.Visible = false;
            FromaDateLabel.Visible = false;
            Button1.Visible = false;
        }

        protected void CustomerImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            // Hide all GridViews
            SalesGridView3.Visible = false;
            CustomerGridView4.Visible = true;
            EmployeeDAtagridView.Visible = false;
            StockGridView5.Visible = false;

            CustomerLabel.Visible = true;
            Sales.Visible = false;
            StockLabel.Visible = false;
            EmployeeLanel.Visible = false;

            EmployeeSearchLabel.Visible = false;
            searchEmployee.Visible = false;
            CustomerSearchLabel.Visible = true;
            CustomerSearch_TextBox1.Visible = true;
            stockSearch_TextBox1.Visible = false;
            stockSearchLabel.Visible = false;
            fromDateTextBox1.Visible = false;
            TODATE.Visible = false;
            ToDate_TextBox2.Visible = false;
            FromaDateLabel.Visible = false;
            Button1.Visible = false;

        }

        protected void SalesImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            // Hide all GridViews
            
            SalesGridView3.Visible = true;
            CustomerGridView4.Visible = false;
            EmployeeDAtagridView.Visible = false;
            StockGridView5.Visible = false;

            CustomerLabel.Visible = false;
            Sales.Visible = true;
            StockLabel.Visible = false;
            EmployeeLanel.Visible = false;

            EmployeeSearchLabel.Visible = false;
            searchEmployee.Visible = false;
            CustomerSearchLabel.Visible = false;
            CustomerSearch_TextBox1.Visible = false;
            stockSearch_TextBox1.Visible = false;
            stockSearchLabel.Visible = false;
            fromDateTextBox1.Visible = true;
            TODATE.Visible = true;
            ToDate_TextBox2.Visible = true;
            FromaDateLabel.Visible = true;
            Button1.Visible = true;
        }

        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        protected void searchEmployee_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string searchText = searchEmployee.Text.Trim();

                if (string.IsNullOrEmpty(searchText) || searchText.Equals("ALL", StringComparison.OrdinalIgnoreCase))
                {

                    SqlDataSource1.SelectCommand = "SELECT [Employee_ID], [Name], [Email], [Surname], [City_Code], [Street_Address], [City], [Phone_Number], [Hire_Date], [Employee_Type] FROM [Employee]";
                }
                else
                {
                
                    SqlDataSource1.SelectCommand = "SELECT [Employee_ID], [Name], [Email], [Surname], [City_Code], [Street_Address], [City], [Phone_Number], [Hire_Date], [Employee_Type] FROM [Employee] WHERE [Name] LIKE @SearchText";
                    SqlDataSource1.SelectParameters.Clear();
                    SqlDataSource1.SelectParameters.Add("SearchText", searchText + "%");  
                }
             
                EmployeeDAtagridView.DataBind();
            }

            catch (Exception ex)
            {
            
                Response.Write("An error occurred: " + ex.Message);
            }
        }

        protected void CustomerSearch_TextBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string searchText = CustomerSearch_TextBox1.Text.Trim();
                string message = string.Empty;

                // Check if the searchText is not empty and not "ALL" or "all"
                if (!string.IsNullOrEmpty(searchText) && !searchText.Equals("ALL", StringComparison.OrdinalIgnoreCase))
                {
                    // Modify the SQL query to filter customers by name
                    SqlDataSource2.SelectCommand = "SELECT [CustomerID], [Name], [Surname], [Email], [Password] FROM [CustomerWeb] WHERE [Name] LIKE @SearchText";
                    SqlDataSource2.SelectParameters.Clear();
                    SqlDataSource2.SelectParameters.Add("SearchText", searchText + "%"); // Use 'c%' to match names starting with 'c'

                    
                }
                else
                {
                    SqlDataSource2.SelectCommand = "SELECT [CustomerID], [Name], [Surname], [Email], [Password] FROM [CustomerWeb]";
                }

                // Rebind the GridView to apply the filter
                CustomerGridView4.DataBind();

            }
            catch (Exception ex)
            {
             
                Response.Write("An error occurred: " + ex.Message);
            }
        }

        protected void stockSearch_TextBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string searchText =  stockSearch_TextBox1.Text.Trim();

                if (string.IsNullOrEmpty(searchText) || searchText.Equals("ALL", StringComparison.OrdinalIgnoreCase))
                {

                    SqlDataSource3.SelectCommand = "SELECT [Product_ID], [Description], [Quantity]  FROM [Product]";
                }
                else
                {

                    SqlDataSource3.SelectCommand = "SELECT [Product_ID], [Description], [Quantity]  FROM [Product] WHERE [Description] LIKE @SearchText";

                    SqlDataSource3.SelectParameters.Clear();
                    SqlDataSource3.SelectParameters.Add("SearchText", searchText + "%");
                }

                StockGridView5.DataBind();
            }

            catch (Exception ex)
            {

                Response.Write("An error occurred: " + ex.Message);
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string fromDate = fromDateTextBox1.Text;
            string toDate = ToDate_TextBox2.Text;

            string query = "SELECT [OrderID], [Date], [Employee_ID], [Employee_Name], [OrderTotal] FROM [OrderTable7] WHERE [Date] BETWEEN @FromDate AND @ToDate";

            // Set the parameters for the query
            SqlDataSource4.SelectParameters.Clear();
            SqlDataSource4.SelectParameters.Add("FromDate", fromDate);
            SqlDataSource4.SelectParameters.Add("ToDate", toDate);

            SqlDataSource4.SelectCommand = query;
            SalesGridView3.DataBind();
        }
    }
}
