﻿using System.Web.UI;

namespace CheckMWebs.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}